import { redirect } from "next/navigation";
import { readSession } from "@/lib/session";

export default function Home() {
  redirect(readSession() ? "/dashboard" : "/login");
}
