"use client";

import { useEffect } from "react";
import { useAuthStore } from "@/lib/authStore";
import MarketIndexStrip from "@/components/market/MarketIndexStrip";

export default function Topbar() {
  const { refresh } = useAuthStore();

  useEffect(() => {
    refresh();
  }, [refresh]);

  return (
    <header className="shrink-0 border-b border-aveon-border bg-aveon-panel">
      <MarketIndexStrip />
    </header>
  );
}
