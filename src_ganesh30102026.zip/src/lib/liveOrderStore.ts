"use client";

import { create } from "zustand";
import { normalizeOrder, normalizeTrade, type OrderModel, type TradeModel, type RawOrderModel, type RawTradeModel } from "@/types/trading";

interface LiveOrderState {
  orders: OrderModel[];
  trades: TradeModel[];
  initialized: boolean;
  setOrders: (orders: OrderModel[]) => void;
  setTrades: (trades: TradeModel[]) => void;
  upsertOrder: (raw: RawOrderModel) => void;
  addTrade: (raw: RawTradeModel) => void;
  reset: () => void;
}

export const useLiveOrderStore = create<LiveOrderState>((set) => ({
  orders: [],
  trades: [],
  initialized: false,
  setOrders: (orders) => set({ orders, initialized: true }),
  setTrades: (trades) => set({ trades }),
  upsertOrder: (raw) => set((state) => {
    const updated = normalizeOrder(raw);
    if (!updated.order_id) return state;
    const index = state.orders.findIndex((o) => o.order_id === updated.order_id);
    if (index >= 0) {
      const copy = [...state.orders];
      copy[index] = updated;
      return { orders: copy };
    }
    return { orders: [updated, ...state.orders] };
  }),
  addTrade: (raw) => set((state) => {
    const updated = normalizeTrade(raw);
    if (!updated.trade_id) return state;
    if (state.trades.some((t) => t.trade_id === updated.trade_id)) return state;
    return { trades: [updated, ...state.trades] };
  }),
  reset: () => set({ orders: [], trades: [], initialized: false }),
}));