import { EventEmitter } from "events";
import { ODINMarketFeedClient } from "odin-market-feed-client";
import type { StoredSession } from "@/lib/session";

type DepthLevel = { price: number; quantity: number; orders: number };

// SynapseWave/mobile uses batches of 90 touchline subscriptions. Keep the
// web feed aligned with that proven runtime behaviour; very large one-shot
// subscription packets can be acknowledged while only a subset actually
// becomes active on the broadcast gateway.
const TOUCHLINE_BATCH_SIZE = 90;

// When the last browser stream stops wanting a token we wait this long before
// unsubscribing it at the gateway. Opening a symbol's depth makes the page
// rebuild its feed stream (twice), so the same ~50 tokens are released and
// requested again within a second or two. Without a grace period every one of
// those rebuilds sent a burst of unsubscribe + subscribe commands that could
// overlap and leave tokens unsubscribed (LTP frozen). Override with
// FEED_RELEASE_GRACE_MS if needed.
const RELEASE_GRACE_MS = Number(process.env.FEED_RELEASE_GRACE_MS) || 8_000;

function batches<T>(items: T[], size = TOUCHLINE_BATCH_SIZE): T[][] {
  const result: T[][] = [];
  for (let i = 0; i < items.length; i += size) {
    result.push(items.slice(i, i + size));
  }
  return result;
}

/** Converts an ODIN FIX-style packet into the JSON shape the SSE client uses. */
/** Converts an ODIN FIX-style packet into the JSON shape the SSE client uses. */
function decodeOdinPacket(message: string): Record<string, unknown> | null {
  const tags: Record<string, string> = {};
  const parts = message.split("|").flatMap((part) => part.split("$"));
  for (const part of parts) {
    const separator = part.indexOf("=");
    if (separator > 0) tags[part.slice(0, separator)] = part.slice(separator + 1);
  }

  const token = tags["7"]; // Security Code
  const mktSegId = Number(tags["1"]); // Segment Id
  if (!token || !Number.isFinite(mktSegId)) return null;

  const scale = Number(tags["399"]) > 0 ? Number(tags["399"]) : 100; // Decimal Locator
  const number = (value: string | undefined) => Number(value) || 0;
  const price = (value: string | undefined) => number(value) / scale;

  // Safely parse percentage strings like "+0.55" or "-0.18"
  const parsePercent = (val: string | undefined) => {
    if (val === undefined) return 0;
    const cleaned = String(val).replace("%", "").trim();
    const parsed = Number(cleaned);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  
    // Identify the packet type explicitly using the ODIN message tag.
  // Best-Five packets must update depth without overwriting the
  // latest touchline LTP.
  const isDepthPacket = tags["64"] === "128";

  const depth = isDepthPacket ? {
    ...decodeDepth(parts, scale),
    totalBuyQty: number(tags["81"]),
    totalSellQty: number(tags["82"]),
    avgTradedPrice: price(tags["80"]),
    week52High: price(tags["93"]),
    week52Low: price(tags["94"]),
    circuitRange: tags["380"],
  } : undefined;

  return {
    mktSegId,                                     // Tag 1: Segment Id
    token,                                        // Tag 7: Security Code
    ltp: price(tags["8"]),                        // Tag 8: Last Trade Price
    ltq: number(tags["9"]),                       // Tag 9: Last Trade Quantity
    bidQty: number(tags["2"]),                    // Tag 2: Buy Qty
    buyQty: number(tags["2"]),                    // Tag 2: Buy Qty (alias)
    sellQty: number(tags["5"]),                   // Tag 5: Sell Qty (alias)
    askQty: number(tags["5"]),                    // Tag 5: Sell Qty
    bidPrice: price(tags["3"]),                   // Tag 3: Buy Price
    askPrice: price(tags["6"]),                   // Tag 6: Sell Price
    lastTradeTime: tags["73"] ?? "",              // Tag 73: Last Trade Time
    lastUpdateTime: tags["74"] ?? "",             // Tag 74: Last Update Time
    openInterest: number(tags["88"]),             // Tag 88: Open Interest
    
    netChange: parsePercent(tags["54"]),          // Tag 54: Net Change From Prev Close (%)
    changePercent: parsePercent(tags["54"]),      // Tag 54: Net Change Percent mapping
    change_percent: parsePercent(tags["54"]),
    closePrice: price(tags["76"] ?? tags["250"]), // Tag 76: Close Price (fallback to Tag 250)
    previousDayClosePrice: price(tags["250"]),    // Tag 250: Previous Day Close Price
    open: price(tags["75"]),                      // Tag 75: Open Price
    high: price(tags["77"]),                      // Tag 77: High Price
    low: price(tags["78"]),                       // Tag 78: Low Price
    volume: number(tags["79"]),                   // Tag 79: Volume
    avgTradedPrice: price(tags["80"]),            // Tag 80: Average Traded Price
    totalBuyQty: number(tags["81"]),              // Tag 81: Total Buy Qty
    totalSellQty: number(tags["82"]),             // Tag 82: Total Sell Qty
    lifetimeHigh: price(tags["93"]),              // Tag 93: Life Time High
    lifetimeLow: price(tags["94"]),               // Tag 94: Life Time Low
    marketType: tags["38"] ?? "",                 // Tag 38: Market Type
    openInterestPercentage: number(tags["465"]),  // Tag 465: Open Interest Percentage
    highOpenInterest: number(tags["466"]),        // Tag 466: High Open Interest
    lowOpenInterest: number(tags["467"]),         // Tag 467: Low Open Interest
    dailyPriceRange: tags["380"] ?? "",           // Tag 380: Daily Price Range
    tradeExecutionRange: tags["499"] ?? "",       // Tag 499: Trade Execution Range
    
    // In src/server/marketFeedManager.ts
    change: tags["393"] !== undefined ? number(tags["393"]) : 0,
    
    decimalLocator: scale,                        // Tag 399: Decimal Locator
    casReferencePrice: price(tags["417"]),        // Tag 417: CAS Ref Price
    indicativeClosePrice: price(tags["418"]),     // Tag 418: Indicative Close Price
    imbalanceQtyEquiPrice: price(tags["419"]),    // Tag 419: Imbalance Qty Equi Price
    imbalanceQtyMarketOrderEquiPrice: price(tags["420"]), // Tag 420: Imbalance Qty Mkt Order Equi Price
    ...(depth ? { depth } : {}),
  };
}

function decodeDepth(parts: string[], scale: number): { bids: DepthLevel[]; asks: DepthLevel[] } {
  const bids: DepthLevel[] = [];
  const asks: DepthLevel[] = [];
  let side = 0;
  let level: Record<string, string> = {};
  const flush = () => {
    if ((side !== 1 && side !== 2) || level["12"] === undefined || level["14"] === undefined) {
      level = {};
      return;
    }
    const parsed = { quantity: Number(level["12"]) || 0, price: (Number(level["14"]) || 0) / scale, orders: Number(level["37"]) || 0 };
    (side === 1 ? bids : asks).push(parsed);
    level = {};
  };
  for (const part of parts) {
    const separator = part.indexOf("=");
    if (separator <= 0) continue;
    const key = part.slice(0, separator);
    const value = part.slice(separator + 1);
    if (key === "11") {
      flush();
      side = Number(value);
    } else if (key === "12" && Object.keys(level).length > 0) {
      flush();
      level[key] = value;
    } else if (side === 1 || side === 2) {
      level[key] = value;
    }
  }
  flush();
  return { bids: bids.slice(0, 5), asks: asks.slice(0, 5) };
}

/**
 * One persistent ODIN Market Feed connection per logged-in user, shared
 * across every browser tab/SSE subscriber for that user. Built on the
 * official `odin-market-feed-client` npm package, which handles the
 * ZLIB-compressed binary framing internally — we only deal with its clean
 * `onMessage(message: string)` callback.
 *
 * This relies on the Next.js server being a long-running Node process
 * (`next dev` / `next start`), not a serverless/edge function — module-level
 * state like this `connections` map wouldn't survive between invocations in
 * a serverless deployment.
 */
class FeedConnection {
  readonly client = new ODINMarketFeedClient();
  readonly emitter = new EventEmitter();
  ready = false;
  private pendingTokens = new Set<string>();
  private subscribedTokens = new Set<string>();
  private subscriptionCounts = new Map<string, number>();
  private depthSubscriptionCounts = new Map<string, number>();
  private loggedSamples = 0;
  private traceSubscriptionCounts = new Map<string, number>();
  private traceSamples = new Map<string, number>();
  private connectPromise: Promise<void> | null = null;
  // Every gateway subscribe/unsubscribe goes through this queue, one command
  // group at a time, so an unsubscribe can never land in the middle of (or
  // after) a newer subscribe for the same tokens.
  private opQueue: Promise<unknown> = Promise.resolve();
  // token -> time after which it is really unsubscribed (see RELEASE_GRACE_MS)
  private pendingDrops = new Map<string, number>();
  private dropTimer: ReturnType<typeof setTimeout> | null = null;
  // Best-Five tokens currently subscribed at the gateway
  private depthActive = new Set<string>();

  constructor(private session: StoredSession) {
    this.emitter.setMaxListeners(500);

    this.client.onOpen = async () => {
      this.ready = true;
      // Snapshot pending tokens, but re-check ownership around each awaited
      // subscribe. An SSE client can disconnect while the gateway call is in
      // flight; subscribing a released token would leave an orphaned feed.
      const pending = Array.from(this.pendingTokens).filter((token) => this.subscribedTokens.has(token));
      for (const batch of batches(pending)) {
        const activeBatch = batch.filter((token) => this.subscribedTokens.has(token) && this.pendingTokens.has(token));
        if (activeBatch.length === 0) continue;
        try {
          // Match the mobile Synapse feed: subscribe both LTP/touchline
          // and full touchline for every batch.
          await this.client.subscribeLTPTouchline(activeBatch);
          await this.client.subscribeTouchline(activeBatch, "0", false);
          const releasedDuringSubscribe = activeBatch.filter((token) => !this.subscribedTokens.has(token));
          if (releasedDuringSubscribe.length > 0) {
            try {
              await this.client.UnsubscribeLTPTouchline(releasedDuringSubscribe);
              await this.client.unsubscribeTouchline(releasedDuringSubscribe);
            } catch { /* best-effort cleanup for a released in-flight subscription */ }
          }
          activeBatch.forEach((token) => {
            if (this.subscribedTokens.has(token)) this.pendingTokens.delete(token);
          });
        } catch (err) {
          // Leave still-active tokens pending so a later reconnect can retry.
          // eslint-disable-next-line no-console
          console.error("[AveonTrade] Feed subscribe-on-open failed:", err);
        }
      }
      for (const tokenKey of Array.from(this.depthSubscriptionCounts.keys())) {
        const [segment, token] = tokenKey.split("_");
        const marketSegmentId = Number(segment);
        if (!token || !Number.isFinite(marketSegmentId) || !this.depthSubscriptionCounts.has(tokenKey)) continue;
        try {
          await this.client.subscribeBestFive(token, marketSegmentId);
          this.depthActive.add(tokenKey);
          // If the last depth consumer left during the gateway call, undo it.
          if (!this.depthSubscriptionCounts.has(tokenKey)) {
            try { await this.client.unsubscribeBestFive(token, marketSegmentId); } catch { /* best-effort */ }
            this.depthActive.delete(tokenKey);
          }
        } catch (err) {
          // eslint-disable-next-line no-console
          console.error("[AveonTrade] Best-Five subscribe-on-open failed:", err);
        }
      }
    };

    this.client.onMessage = (message: string) => {
      if (this.loggedSamples < 5) {
        this.loggedSamples += 1;
        // eslint-disable-next-line no-console
        console.log(`[AveonTrade] Feed raw message #${this.loggedSamples}:`, message.slice(0, 500));
      }
      // parseData only splits transport frames; it does not decode ODIN's
      // pipe/$-delimited FIX tags. Decode each candidate packet ourselves.
      // responseReceived() in the client already gives us a decoded
      // `63=FIX3.0|...` packet. Calling parseData() on that packet treats
      // "3=FIX" as a transport length and corrupts it (for example to
      // "IX3"), so only use parseData for a non-FIX transport frame.
      let frames: string[] = [message];
      if (!message.includes("|")) {
        try {
          const splitFrames = this.client.parseData(message) ?? [];
          if (splitFrames.length > 0) frames = splitFrames;
        } catch {
          // A direct ODIN packet is still decodable without a transport frame.
        }
      }
      let emitted = false;
      for (const frame of frames) {
        const record = decodeOdinPacket(frame);
        if (record) {
          emitted = true;
          const traceKey = `${String(record.mktSegId)}_${String(record.token)}`;
          if (this.traceSubscriptionCounts.has(traceKey)) {
            const sampleCount = this.traceSamples.get(traceKey) ?? 0;
            if (sampleCount < 3) {
              this.traceSamples.set(traceKey, sampleCount + 1);
              // eslint-disable-next-line no-console
              console.log(`[AveonTrade][OptionChainTrace] decoded ${traceKey}:`, {
                ltp: record.ltp,
                bidPrice: record.bidPrice,
                bidQty: record.bidQty,
                askPrice: record.askPrice,
                askQty: record.askQty,
                openInterest: record.openInterest,
                change: record.change,
                changePercent: record.changePercent,
              });
            }
          }
          this.emitter.emit("tick", record);
        }
      }
      if (!emitted) this.emitter.emit("raw", message);
    };

    this.client.onError = (error: string) => {
      // eslint-disable-next-line no-console
      console.error("[AveonTrade] Feed error:", error);
      this.emitter.emit("connection-error", error);
    };

    this.client.onClose = (code: number, reason: string) => {
      // eslint-disable-next-line no-console
      console.log("[AveonTrade] Feed closed:", code, reason);
      this.ready = false;
      if (this.dropTimer) clearTimeout(this.dropTimer);
      this.dropTimer = null;
      this.pendingDrops.clear();
      this.depthActive.clear();
      registry.delete(session.userId);
      this.emitter.emit("closed", { code, reason });
    };
  }

  
connect(): Promise<void> {
  if (!this.connectPromise) {
    const host = this.session.broadcastHost;
    const port = this.session.broadcastPort;
    const ssl = this.session.broadcastSsl ?? true;

    // Require a valid broker-provided broadcast server.
    // Do not fall back to a hardcoded hostname.
    if (
      !host ||
      !Number.isFinite(port) ||
      !port ||
      port < 1 ||
      port > 65535
    ) {
      return Promise.reject(
        new Error(
          "Broadcast server is not configured correctly. Check the broker login response or broadcast URL configuration."
        )
      );
    }

    // eslint-disable-next-line no-console
    console.log(
      `[AveonTrade] Feed connecting -> host=${host} port=${port} ssl=${ssl} userId=${this.session.userId}`
    );

    // Preserve existing broadcast authentication.
    const token =
      this.session.broadcastToken || this.session.accessToken;

    const connectCall = this.client.connect(
      host,
      port,
      ssl,
      this.session.userId,
      token
    );

    const timeout = new Promise<never>((_, reject) =>
      setTimeout(
        () =>
          reject(
            new Error(
              `Feed connect() timed out after 10s connecting to ${host}:${port}`
            )
          ),
        10_000
      )
    );

    this.connectPromise = Promise.race([
      connectCall,
      timeout,
    ]).catch((err) => {
      // eslint-disable-next-line no-console
      console.error(
        "[AveonTrade] Feed connect() failed:",
        err?.message ?? err
      );

      this.connectPromise = null;
      throw err;
    });
  }

  return this.connectPromise;
}

  /** Runs gateway commands strictly one after another, in the order they were requested. */
  private enqueue<T>(op: () => Promise<T>): Promise<T> {
    const run = this.opQueue.then(op);
    this.opQueue = run.catch(() => undefined);
    return run;
  }

  async subscribe(tokens: string[]) {
    const fresh: string[] = [];
    for (const token of new Set(tokens)) {
      const count = this.subscriptionCounts.get(token) ?? 0;
      this.subscriptionCounts.set(token, count + 1);
      if (count === 0) {
        // Wanted again inside the grace period after a release: the gateway
        // subscription is still live, so there is nothing to send.
        if (this.pendingDrops.delete(token) && this.subscribedTokens.has(token)) continue;
        this.subscribedTokens.add(token);
        fresh.push(token);
      }
    }
    if (fresh.length === 0) return;
    fresh.forEach((t) => this.pendingTokens.add(t));
    if (!this.ready) return;
    await this.enqueue(async () => {
      for (const batch of batches(fresh)) {
        const activeBatch = batch.filter((token) => this.subscribedTokens.has(token));
        if (activeBatch.length === 0) continue;
        // The mobile app subscribes in batches and requests both touchline
        // variants. This is important for large FO option-chain subscriptions.
        await this.client.subscribeLTPTouchline(activeBatch);
        await this.client.subscribeTouchline(activeBatch, "0", false);
        const releasedDuringSubscribe = activeBatch.filter((token) => !this.subscribedTokens.has(token));
        if (releasedDuringSubscribe.length > 0) {
          try {
            await this.client.UnsubscribeLTPTouchline(releasedDuringSubscribe);
            await this.client.unsubscribeTouchline(releasedDuringSubscribe);
          } catch { /* best-effort cleanup for a released in-flight subscription */ }
        }
        activeBatch.forEach((token) => {
          if (this.subscribedTokens.has(token)) this.pendingTokens.delete(token);
        });
      }
    });
  }

  async release(tokens: string[]) {
    const dropAt = Date.now() + RELEASE_GRACE_MS;
    for (const token of new Set(tokens)) {
      const count = this.subscriptionCounts.get(token) ?? 0;
      if (count <= 1) {
        this.subscriptionCounts.delete(token);
        // Not unsubscribed yet: only scheduled, so a quick re-subscribe is free.
        if (this.subscribedTokens.has(token)) this.pendingDrops.set(token, dropAt);
      } else {
        this.subscriptionCounts.set(token, count - 1);
      }
    }
    this.scheduleDropFlush();
  }

  private scheduleDropFlush() {
    if (this.dropTimer || this.pendingDrops.size === 0) return;
    const nextAt = Math.min(...Array.from(this.pendingDrops.values()));
    this.dropTimer = setTimeout(() => {
      this.dropTimer = null;
      void this.flushDrops();
    }, Math.max(0, nextAt - Date.now()) + 50);
  }

  /** Really unsubscribes the tokens whose grace period ended and that nobody asked for again. */
  private async flushDrops() {
    const now = Date.now();
    const due: string[] = [];
    for (const [token, at] of Array.from(this.pendingDrops.entries())) {
      if (at > now) continue;
      this.pendingDrops.delete(token);
      if (!this.subscriptionCounts.has(token) && this.subscribedTokens.has(token)) due.push(token);
    }
    this.scheduleDropFlush();
    if (due.length === 0) return;
    due.forEach((t) => {
      this.subscribedTokens.delete(t);
      this.pendingTokens.delete(t);
    });
    // eslint-disable-next-line no-console
    console.log(`[AveonTrade] Feed: unsubscribing ${due.length} token(s) nobody asked for in the last ${RELEASE_GRACE_MS / 1000}s`);
    if (!this.ready) return;
    await this.enqueue(async () => {
      // Skip any token that was subscribed again while this command waited in the queue.
      const stillDue = due.filter((t) => !this.subscribedTokens.has(t));
      if (stillDue.length === 0) return;
      try {
        for (const batch of batches(stillDue)) {
          await this.client.UnsubscribeLTPTouchline(batch);
          await this.client.unsubscribeTouchline(batch);
        }
      } catch {
        /* best-effort */
      }
    });
  }

  enableTrace(tokens: string[]) {
    for (const token of new Set(tokens)) {
      this.traceSubscriptionCounts.set(token, (this.traceSubscriptionCounts.get(token) ?? 0) + 1);
    }
    // eslint-disable-next-line no-console
    console.log(
      `[AveonTrade][OptionChainTrace] tracing ${tokens.length} requested token(s) in ${batches(tokens).length} batch(es) of <=${TOUCHLINE_BATCH_SIZE}:`,
      tokens,
    );
  }

  disableTrace(tokens: string[]) {
    for (const token of new Set(tokens)) {
      const count = this.traceSubscriptionCounts.get(token) ?? 0;
      if (count <= 1) this.traceSubscriptionCounts.delete(token);
      else this.traceSubscriptionCounts.set(token, count - 1);
    }
  }

  async subscribeDepth(tokenKey: string) {
    const [segment, token] = tokenKey.split("_");
    if (!token || !Number.isFinite(Number(segment))) return;
    this.depthSubscriptionCounts.set(tokenKey, (this.depthSubscriptionCounts.get(tokenKey) ?? 0) + 1);
    await this.reconcileDepth(tokenKey);
  }

  async releaseDepth(tokenKey: string) {
    const count = this.depthSubscriptionCounts.get(tokenKey) ?? 0;
    if (count > 1) {
      this.depthSubscriptionCounts.set(tokenKey, count - 1);
      return;
    }
    this.depthSubscriptionCounts.delete(tokenKey);
    await this.reconcileDepth(tokenKey);
  }

  /**
   * Brings the gateway in line with what consumers currently want for one
   * Best-Five token. Runs in the shared queue and decides at execution time, so
   * "release A then subscribe A" (the page rebuilding its stream) ends subscribed
   * and never sends a pointless unsubscribe/subscribe pair.
   */
  private reconcileDepth(tokenKey: string): Promise<void> {
    return this.enqueue(async () => {
      const [segment, token] = tokenKey.split("_");
      const marketSegmentId = Number(segment);
      if (!token || !Number.isFinite(marketSegmentId) || !this.ready) return; // onOpen subscribes wanted tokens
      const wanted = this.depthSubscriptionCounts.has(tokenKey);
      const active = this.depthActive.has(tokenKey);
      if (wanted && !active) {
        // eslint-disable-next-line no-console
        console.log(`[AveonTrade] Feed: Best-Five subscribe ${tokenKey}`);
        await this.client.subscribeBestFive(token, marketSegmentId);
        this.depthActive.add(tokenKey);
      } else if (!wanted && active) {
        // eslint-disable-next-line no-console
        console.log(`[AveonTrade] Feed: Best-Five unsubscribe ${tokenKey}`);
        try { await this.client.unsubscribeBestFive(token, marketSegmentId); } catch { /* best-effort */ }
        this.depthActive.delete(tokenKey);
      }
    });
  }
}

const registry = new Map<string, FeedConnection>();

export async function getFeedConnection(session: StoredSession): Promise<FeedConnection> {
  let entry = registry.get(session.userId);
  if (!entry) {
    entry = new FeedConnection(session);
    registry.set(session.userId, entry);
  }
  await entry.connect();
  return entry;
}
