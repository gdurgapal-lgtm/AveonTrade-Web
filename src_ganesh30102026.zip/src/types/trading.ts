// Ported from lib/features/orders/models/order_model.dart,
// lib/features/positions/models/position_model.dart, and related files.
// Field names use the broker's snake_case shape since data comes straight
// through the proxy from the REST API.

export type OrderStatus = string;

export type TransactionType = "BUY" | "SELL";
export type ProductType = "CNC" | "MIS" | "NRML" | "CO" | "BO";
export type OrderType = "MARKET" | "LIMIT" | "SL" | "SL-M";
export type Validity = "DAY" | "IOC" | "GTD" | "EOS";

/**
 * BSE uses its own validity codes. The UI keeps the familiar labels and the
 * API value is swapped at the edge:  DAY <-> EOTODY,  EOS <-> EOSESS.
 * IOC and GTD are identical on every exchange.
 */
export function validityToApi(validity: string, segmentLike?: string): string {
  const value = String(validity ?? "DAY").trim().toUpperCase();
  const isBse = String(segmentLike ?? "").toUpperCase().includes("BSE");
  if (isBse) {
    if (value === "DAY") return "EOTODY";
    if (value === "EOS") return "EOSESS";
    return value;
  }
  return value === "EOS" ? "DAY" : value; // EOS only exists on BSE
}

/** Order-book values coming back from the API -> the labels shown in the UI. */
export function validityFromApi(validity: string): string {
  const value = String(validity ?? "DAY").trim().toUpperCase();
  if (value === "EOTODY") return "DAY";
  if (value === "EOSESS") return "EOS";
  return value;
}

export interface OrderModel {
  order_id: string;
  exchange: string;
  exchange_order_no?: string;
  scrip_token?: number;
  trading_symbol: string;
  series?: string;
  transaction_type: TransactionType;
  product_type: ProductType | string;
  order_type: OrderType | string;
  quantity: number;
  filled_quantity?: number;
  pending_quantity?: number;
  disclosed_quantity?: number;
  price: number;
  trigger_price?: number;
  average_price?: number;
  status: OrderStatus;
  validity: Validity | string;
  validity_days?: number;
  order_timestamp?: string;
  error_reason?: string;
  message?: string;
  is_amo?: boolean;
  order_identifier?: string;
  gateway_order_no?: string;
  raw?: Record<string, any>;
}

export interface TradeModel {
  trade_id: string;
  order_id: string;
  exchange: string;
  exchange_order_no?: string;
  scrip_token?: number;
  trading_symbol: string;
  series?: string;
  transaction_type: TransactionType;
  product_type?: string;
  order_type?: string;
  quantity: number;
  price: number;
  trade_timestamp?: string;
  order_identifier?: string;
  raw?: Record<string, any>;
}

export interface PositionModel {
  exchange: string;
  preferred_exchange?: string;
  scrip_token?: string | number;
  preferred_scrip_token?: string | number;
  symbol: string;
  series?: string;
  product_type: ProductType | string;
  instrument?: string;
  expiry_date?: string;
  strike_price?: string;
  option_type?: string;
  market_lot?: number;
  buy_quantity: number;
  avg_buy_price: number;
  buy_value: number;
  sell_quantity: number;
  avg_sell_price: number;
  sell_value: number;
  net_quantity: number;
  net_price: number;
  net_value: number;
  cf_buy_value?: number;
  cf_sell_value?: number;
  cf_net_price?: number;
  reference_rate?: number;
  gen_num?: number;
  gen_den?: number;
  price_num?: number;
  price_den?: number;
  unsettled_quantity?: number;
  multiplier?: number;
  daily_or_expiry?: string;
}


export interface HoldingSecurity { exchange: string; scrip_token: number; symbol: string; }

export interface HoldingModel {
  isin: string;
  security_info: HoldingSecurity[];
  exchange: string;
  scrip_token: number;
  trading_symbol: string;
  quantity: number;
  dp_free: number;
  pool_free: number;
  t1_quantity: number;
  avg_price: number;
  ltp: number;
  close_price: number;
  current_value: number;
  invested_value: number;
  pnl: number;
  pnl_percent: number;
  day_pnl: number;
  day_pnl_percent: number;
  product?: string;
  collateral_quantity?: number;
  collateral_value?: number;
  dp_pledge_collateral_qty?: number;
  pool_pledge_collateral_qty?: number;
}

export interface RawHoldingModel {
  isin?: string; ISIN?: string;
  security_info?: { exchange: string; scrip_token: string | number; symbol: string }[];
  total_free?: number | string; dp_free?: number | string; pool_free?: number | string; t1_quantity?: number | string;
  average_price?: number | string; last_price?: number | string; pnl?: number | string; current_value?: number | string; inv_value?: number | string;
  product?: string; collateral_quantity?: number | string; collateral_value?: number | string; close_price?: number | string;
  dppledge_collateral_qty?: number | string; poolpledge_collateral_qty?: number | string;
}

export interface FundsSummary {
  available_margin: number;
  used_margin: number;
  total_balance: number;
  payin?: number;
  payout?: number;
  collateral?: number;
  /** Raw labeled rows from getFundsViewSummary, e.g. "Net Available Funds". */
  lines?: { label: string; value: number }[];
}

export interface WatchlistQuote {
  exchange: string;
  trading_symbol: string;
  token?: string;
  ltp: number;
  change: number;
  change_percent: number;
  open: number;
  high: number;
  low: number;
  close: number;
  volume?: number;
  bid_price?: number;
  bid_qty?: number;
  ask_price?: number;
  ask_qty?: number;
  open_interest?: number;
  buy_qty?: number;
  sell_qty?: number;
  last_trade_time?: string;
  last_update_time?: string;
  net_change?: number;
  average_traded_price?: number;
  lifetime_high?: number;
  lifetime_low?: number;
  market_type?: string;
  open_interest_percentage?: number;
  high_open_interest?: number;
  low_open_interest?: number;
  daily_price_range?: string;
  trade_execution_range?: string;
  cas_reference_price?: number;
  indicative_close_price?: number;
  imbalance_qty_equi_price?: number;
  imbalance_qty_market_order_equi_price?: number;
  decimal_locator?: number;
  last_trade_quantity?: number;
  depth?: { bids?: { price: number; quantity: number; orders?: number }[]; asks?: { price: number; quantity: number; orders?: number }[]; totalBuyQty?: number; totalSellQty?: number; avgTradedPrice?: number; week52High?: number; week52Low?: number; circuitRange?: string };
}

export interface RegularOrderRequest {
  exchange: string;
  trading_symbol: string;
  transaction_type: TransactionType;
  product_type: ProductType;
  order_type: OrderType;
  quantity: number;
  price?: number;
  trigger_price?: number;
  validity: Validity;
  disclosed_quantity?: number;
  is_amo?: boolean;
}

/**
 * The broker returns holdings with numbers as strings and the symbol buried
 * in a `security_info` array (one entry per exchange). This picks the
 * NSE entry when available (falls back to the first) and parses numerics.
 */
export function normalizePosition(raw: Record<string, any>): PositionModel {
  const n = (value: unknown) => {
    const parsed = Number(value);
    return Number.isFinite(parsed) ? parsed : 0;
  };
  const text = (value: unknown) => (value === undefined || value === null ? "" : String(value));
  return {
    exchange: text(raw.exchange),
    preferred_exchange: text(raw.preferred_exchange) || undefined,
    scrip_token: raw.scrip_token,
    preferred_scrip_token: raw.preferred_scrip_token,
    symbol: text(raw.symbol),
    series: text(raw.series) || undefined,
    product_type: text(raw.product_type),
    instrument: text(raw.instrument) || undefined,
    expiry_date: text(raw.expiry_date) || undefined,
    strike_price: text(raw.strike_price) || undefined,
    option_type: text(raw.option_type) || undefined,
    market_lot: n(raw.market_lot) || undefined,
    buy_quantity: n(raw.buy_quantity),
    avg_buy_price: n(raw.avg_buy_price),
    buy_value: n(raw.buy_value),
    sell_quantity: n(raw.sell_quantity),
    avg_sell_price: n(raw.avg_sell_price),
    sell_value: n(raw.sell_value),
    net_quantity: n(raw.net_quantity),
    net_price: n(raw.net_price),
    net_value: n(raw.net_value),
    cf_buy_value: n(raw.cf_buy_value),
    cf_sell_value: n(raw.cf_sell_value),
    cf_net_price: n(raw.cf_net_price),
    reference_rate: n(raw.reference_rate),
    gen_num: n(raw.gen_num),
    gen_den: n(raw.gen_den),
    price_num: n(raw.price_num),
    price_den: n(raw.price_den),
    unsettled_quantity: n(raw.unsettled_quantity),
    multiplier: n(raw.multiplier),
    daily_or_expiry: text(raw.daily_or_expiry) || undefined,
  };
}

export function normalizeHolding(raw: RawHoldingModel): HoldingModel {
  const num = (v: unknown) => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
  const security_info = (raw.security_info ?? []).map((x) => ({ exchange: String(x.exchange ?? ""), scrip_token: num(x.scrip_token), symbol: String(x.symbol ?? "") }));
  const preferred = security_info.find((x) => x.exchange === "NSE_EQ") ?? security_info.find((x) => !!x.exchange) ?? security_info[0];
  const isin = String(raw.isin ?? raw.ISIN ?? ""); const quantity = num(raw.total_free); const avg = num(raw.average_price);
  const ltp = num(raw.last_price); const close = num(raw.close_price); const invested = num(raw.inv_value) || avg * quantity;
  const current = num(raw.current_value) || ltp * quantity; const pnl = num(raw.pnl) || current - invested;
  const dayPnl = close > 0 && ltp > 0 ? (ltp - close) * quantity : 0;
  return { isin, security_info, exchange: preferred?.exchange ?? "", scrip_token: preferred?.scrip_token ?? 0, trading_symbol: preferred?.symbol || isin || "--", quantity, dp_free: num(raw.dp_free), pool_free: num(raw.pool_free), t1_quantity: num(raw.t1_quantity), avg_price: avg, ltp, close_price: close, current_value: current, invested_value: invested, pnl, pnl_percent: invested ? (pnl / invested) * 100 : 0, day_pnl: dayPnl, day_pnl_percent: close ? ((ltp - close) / close) * 100 : 0, product: raw.product, collateral_quantity: num(raw.collateral_quantity), collateral_value: num(raw.collateral_value), dp_pledge_collateral_qty: num(raw.dppledge_collateral_qty), pool_pledge_collateral_qty: num(raw.poolpledge_collateral_qty) };
}

export interface Instrument {
  exchange: string;
  token: string;
  symbol: string;
  tradingSymbol: string;
  /** Canonical trading symbol provided by the broker's instrument master. */
  canonicalTradingSymbol?: string;
  companyName: string;
  series?: string;
  isin?: string;
  /** e.g. "NSE_EQ" — needed for the Synapsewave chart-history endpoint. */
  exchangeSegment?: string;
  /** Numeric segment id, used to derive exchangeSegment when it's missing. */
  marketSegmentId?: number;
  /** Authoritative trading segment from instrument master (can differ from quote segment). */
  tradingMarketSegmentId?: number;
  /** "EQUITIES" | "INDEX" | "FUTIDX" | "OPTSTK" | ... — used for filter chips. */
  instrumentName?: string;
  /** "CE" | "PE" for options. */
  optionType?: string;
  /** F&O/commodity fields — blank for equities. */
  expiryDateText?: string;
  strikePrice?: string;
  derivativeDesc?: string;
  displayName?: string;
  isIndex?: boolean;
  regularLot?: number;
  priceTick?: number;
  maxSingleTransactionQty?: number;
  securityStatus?: string;
  securityRemarks?: string;
  qtyUnit?: string;
  deliveryUnit?: string;
  expiryDate?: number;
}

/** Ports search_symbol_screen.dart's isStock/isIndex/isFuture/isOption/isCommodity/isCurrency. */
export type InstrumentKind = "STOCK" | "INDEX" | "FUT" | "OPT" | "COMM" | "CUR" | "OTHER";

export function classifyInstrument(i: Instrument): InstrumentKind {
  const name = (i.instrumentName ?? "").toUpperCase();
  const segment = (i.exchangeSegment ?? "").toUpperCase();
  const exchange = (i.exchange ?? "").toUpperCase();
  const series = (i.series ?? "").toUpperCase();
  const optionType = (i.optionType ?? "").toUpperCase();

  if (optionType === "CE" || optionType === "PE" || name.startsWith("OPT")) return "OPT";
  if (name.startsWith("FUT")) return "FUT";
  if (name === "INDEX") return "INDEX";
  if (
    segment.includes("COMM") || segment.includes("MCX") || segment.includes("NCDEX") ||
    exchange === "MCX" || exchange === "NCDEX"
  ) {
    return "COMM";
  }
  if (segment.includes("CUR") || segment.includes("CDS") || name.includes("CUR")) return "CUR";
  if (
    name === "EQUITIES" &&
    (segment === "NSE_EQ" || segment === "BSE_EQ") &&
    (series === "EQ" || series === "A" || series === "BE" || series === "BZ")
  ) {
    return "STOCK";
  }
  return "OTHER";
}

/** Ports SynapsewaveHistoricalProvider._exchangeSegmentFromMarketSegmentId. */
const SEGMENT_ID_TO_EXCHANGE: Record<number, string> = {
  1: "NSE_EQ",
  2: "NSE_FO",
  3: "BSE_EQ",
  4: "BSE_FO",
  5: "MCX_FO",
  7: "NCDEX_FO",
  6: "MCX_SPOT",
  8: "NCDEX_SPOT",
  9: "NSEL_SPOT",
  10: "NSEL_COM",
  11: "MSE_CDS",
  12: "MSE_CDS_SPOT",
  13: "NSE_CDS",
  14: "NSE_CDS_SPOT",
  15: "MSE_EQ",
  16: "MSE_FO",
  18: "BSE_COMM",
  19: "NSE_COMM",
  25: "BSE_OFS",
  33: "NSE_OFS",
};

export function exchangeSegmentFor(instrument: Instrument): string {
  if (instrument.exchangeSegment) return instrument.exchangeSegment.toUpperCase();
  if (instrument.marketSegmentId) return SEGMENT_ID_TO_EXCHANGE[instrument.marketSegmentId] ?? "";
  return "";
}

/**
 * True when a market segment represents a derivative/contract market.
 * Used only for product presentation and the broker's Delivery payload
 * convention; cash NSE/BSE equity remains Delivery.
 */
export function isDerivativeMarketSegment(segmentLike?: string): boolean {
  const value = String(segmentLike ?? "").trim().toUpperCase();
  if (!value) return false;
  const compact = value.replace(/[^A-Z0-9]/g, "");
  return (
    compact.includes("_FO") ||
    compact.endsWith("FO") ||
    compact.includes("CDS") ||
    compact.endsWith("CD") ||
    compact.includes("COMM") ||
    compact.endsWith("COM") ||
    compact === "MCX" ||
    compact === "NCDEX"
  );
}

/**
 * Product display rule used across Order Book, Trade Book, Positions and
 * other panels. The broker stores derivative Carry Forward orders as
 * Delivery, but AveonTrade displays them as Carry Forward.
 */
export function displayProductType(productType: string, segmentLike?: string, instrumentHint?: string): string {
  const product = String(productType ?? "").trim().toUpperCase();
  const hint = String(instrumentHint ?? "").trim().toUpperCase();
  const derivative = isDerivativeMarketSegment(segmentLike) || /(?:FUT|OPT)/.test(hint);

  if (derivative && ["DELIVERY", "CNC", "CARRYFORWARD", "NRML"].includes(product)) return "Carry Forward";
  if (["DELIVERY", "CNC"].includes(product)) return "Delivery";
  if (["INTRADAY", "MIS"].includes(product)) return "Intraday";
  if (["CARRYFORWARD", "NRML"].includes(product)) return "Carry Forward";
  if (["COVER", "CO"].includes(product)) return "Cover";
  if (["BRACKET", "BO"].includes(product)) return "Bracket";
  return String(productType ?? "");
}


/** Stable watchlist identity: the same symbol can exist on multiple exchange segments. */
export function instrumentIdentityKey(instrument: Instrument): string {
  const segmentId = instrument.marketSegmentId ?? Object.entries(SEGMENT_ID_TO_EXCHANGE).find(
    ([, value]) => value === (instrument.exchangeSegment ?? "").toUpperCase()
  )?.[0];
  const segment = segmentId ? String(segmentId) : (exchangeSegmentFor(instrument) || instrument.exchange || "").toUpperCase();
  // Derivative contracts share an underlying symbol; segment + token uniquely identifies each contract.
  if (instrument.token) return `${segment}:${instrument.token}`;
  return `${segment}:${(instrument.tradingSymbol || instrument.symbol || "").toUpperCase()}`;
}

// Helper to clean up 4-digit years in contract symbols (e.g. CRUDEOIL19NOV2026FUT -> CRUDEOIL19NOV26FUT)
function cleanDerivativeSymbol(sym: string): string {
  if (!sym) return "";
  // Aggressively replace any 20YY year inside contract symbols with YY
  return sym.replace(/20(\d{2})/g, "$1");
}

/**
 * Ports InstrumentModel.fromJson's defensive field fallbacks from
 * lib/features/market_watch/models/instrument_model.dart — the broker's
 * search results use short ES-style keys (sExchange, sSymbol, nToken,
 * sSecurityDesc) while other endpoints use readable snake_case, so every
 * field tries several possible keys.
 */
export function normalizeInstrument(json: Record<string, any>): Instrument {
  const source = json?._source ?? json;
  const first = (...values: unknown[]) => values.find((v) => v !== undefined && v !== null && v !== "") ?? "";

  const rawSecurityDesc = String(first(source.sSecurityDesc, source.security_desc, source.securityDescription));
  const rawSymbol = String(first(source.sSymbol, source.sSymbolnew, source.symbol, source.trading_symbol, source.tradingsymbol));
  
  const cleanedDesc = cleanDerivativeSymbol(rawSecurityDesc || rawSymbol);

  return {
    exchange: String(first(source.exchange, source.sExchange)),
    token: String(first(source.token, source.instrument_token, source.nToken, source.id)),
    symbol: cleanDerivativeSymbol(String(first(source.symbol, source.sSymbol, source.sSymbolnew))),
    canonicalTradingSymbol: cleanedDesc || undefined,
    tradingSymbol: cleanedDesc || String(
      first(
        source.sSecurityDesc,
        source.security_desc,
        source.securityDescription,
        source.trading_symbol,
        source.tradingsymbol,
        source.sSymbolnew,
        source.sSymbol,
        source.symbol
      )
    ),
    companyName: String(first(source.company_name, source.name, source.sSecurityDesc)),
    displayName: String(first(source.display_name, source.sSymbolnew, source.sSymbol, source.symbol)) || undefined,
    series: String(first(source.series, source.sSeries)) || undefined,
    isin: String(first(source.isin, source.sISINCode)) || undefined,
    exchangeSegment: String(first(source.exchange_segment, source.ExchangeSegment, source.sExchangeSegment)) || undefined,
    marketSegmentId:
      Number(first(source.market_segment_id, source.MktSegId, source.nMarketSegmentId)) || undefined,
    tradingMarketSegmentId:
      Number(first(source.trading_market_segment_id, source.TradingMarketSegmentId, source.nTradingMarketSegmentId)) || undefined,
    instrumentName: String(first(source.instrument, source.instrument_name, source.instrumentName, source.sInstrumentName)) || undefined,
    optionType: String(first(source.option_type, source.optionType, source.sOptionType)) || undefined,
    expiryDateText: String(first(source.expiry_date_text, source.sExpiryDate, source.ExpiryDate, source.expiryDateText, source.nExpiryDate1)) || undefined,
    expiryDate: Number(first(source.expiry_date, source.nExpiryDate, source.nExpiryDate1)) || undefined,
    strikePrice: String(first(source.strike_price, source.sStrikePrice, source.nStrikePrice, source.StrikePrice, source.strikePrice)) || undefined,
    derivativeDesc: String(first(source.derivative_desc, source.sDerivitiveDesc)) || undefined,
    isIndex: ["TRUE", "1", "Y", "YES"].includes(String(first(source.is_index, source.isIndex, source.IsIndex, source.isindex, source.nIsIndex)).toUpperCase()),
    regularLot: Number(first(source.regular_lot, source.nRegularLot)) || undefined,
    priceTick: Number(first(source.price_tick, source.nPriceTick, source.tick_size, source.tickSize)) || undefined,
    maxSingleTransactionQty: Number(first(source.max_single_transaction_qty, source.nMaxSingleTransactionQty, source.maxSingleTransactionQty)) || undefined,
    securityStatus: String(first(source.security_status, source.sSecurityStatus, source.securityStatus)) || undefined,
    securityRemarks: String(first(source.security_remarks, source.sSecurityRemarks, source.securityRemarks)) || undefined,
    qtyUnit: String(first(source.qty_unit, source.sQtyUnit)) || undefined,
    deliveryUnit: String(first(source.delivery_unit, source.sDeliveryUnit)) || undefined,
  };
}

// ---------------------------------------------------------------------------
// Order / Trade normalization — the broker's actual field names vary wildly
// per endpoint (symbol vs trading_symbol vs sSymbol, order_price vs price,
// etc). Ported from OrderModel.fromJson / TradeModel.fromJson's defensive
// key-fallback lists in lib/features/orders/models/{order,trade}_model.dart.
// ---------------------------------------------------------------------------

export type RawOrderModel = Record<string, any>;
export type RawTradeModel = Record<string, any>;

function firstString(raw: Record<string, any>, keys: string[]): string {
  for (const k of keys) {
    const v = raw?.[k];
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return "";
}

function firstNumber(raw: Record<string, any>, keys: string[]): number {
  for (const k of keys) {
    const v = raw?.[k];
    if (v !== undefined && v !== null && v !== "") {
      const n = Number(v);
      if (Number.isFinite(n)) return n;
    }
  }
  return 0;
}

/** Maps the broker's varied raw status strings onto a badge tone (not a strict enum — too many broker-specific labels to enumerate safely). */
export function orderStatusTone(status: string): "buy" | "sell" | "warn" | "neutral" {
  const s = status.toUpperCase();
  if (s.includes("COMPLETE") || s.includes("EXECUTED") || s.includes("FILLED")) return "buy";
  if (s.includes("REJECT") || s.includes("ERROR")) return "sell";
  if (s.includes("CANCEL")) return "neutral";
  return "warn"; // PENDING, ACTIVE, OMSXMITTED, EXXMITTED, AMOACCEPTED, TRIGGER_PENDING, ...
}

function rawContractDisplaySymbol(raw: RawOrderModel): string {
  const canonical = firstString(raw, [
    "sSecurityDesc",
    "security_desc",
    "securityDescription",
    "TradingSymbol",
    "trading_symbol",
    "tradingSymbol"
  ]);
  if (/(?:CE|PE|FUT)$/i.test(canonical)) {
    return cleanDerivativeSymbol(canonical);
  }

  const exchange = firstString(raw, ["exchange","exchange_segment","exchangeSegment","segment"]);
  const instrument = firstString(raw, ["instrument","instrument_name","instrumentName","_InstrumentName","sInstrumentName"]);
  const symbol = firstString(raw, ["symbol","sSymbol","sSymbolnew","sSymbolNew"]) || "CRUDEOIL";
  const segment = String(exchange).toUpperCase();
  const derivative = isDerivativeMarketSegment(segment) || /(?:FUT|OPT)/i.test(instrument);
  if (!derivative) return symbol;

  const rawExpiry = firstString(raw, ["expiry_date","expiryDate","expiry","ExpiryDate","nExpiryDate1"]);
  const option = firstString(raw, ["option_type","optionType","OptionType"]).toUpperCase();
  const strike = firstString(raw, ["strike_price","strikePrice","StrikePrice"]);
  const isFuture = instrument.includes("FUT") || !option || option === "  " || option === "";

  let formattedExpiry = "";
  if (rawExpiry) {
    const d = new Date(rawExpiry);
    if (!isNaN(d.getTime())) {
      const yy = String(d.getFullYear()).slice(-2);
      const mNames = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];
      const mLetter = mNames[d.getMonth()];
      const dd = String(d.getDate()).padStart(2, "0");
      
      if (isFuture) {
        formattedExpiry = `${dd}${mLetter}${yy}`;
      } else {
        const shortLetter = ["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"][d.getMonth()];
        formattedExpiry = `${yy}${shortLetter}${dd}`;
      }
    } else {
      formattedExpiry = rawExpiry.replace(/20(\d{2})/, "$1").replace(/[^A-Z0-9]/g, "");
    }
  }

  if (symbol && formattedExpiry) {
    if (!isFuture && (option === "CE" || option === "PE")) {
      const strikeClean = strike.split(".")[0].replace(/,/g, "");
      if (strikeClean) return cleanDerivativeSymbol(`${symbol}${formattedExpiry}${strikeClean}${option}`);
    }
    return cleanDerivativeSymbol(`${symbol}${formattedExpiry}FUT`);
  }

  return cleanDerivativeSymbol(symbol);
}

function compactDerivativeExpiry(value: string): string {
  const raw = String(value ?? "").trim().toUpperCase();
  if (!raw || raw === "-") return "";
  let m = raw.match(/^(\d{1,2})[-\/ ]([A-Z]{3})[-\/ ](?:20)?\d{2}$/);
  if (m) return `${m[1].padStart(2, "0")}${m[2]}`;
  m = raw.match(/^(\d{4})[-\/](\d{1,2})[-\/](\d{1,2})/);
  if (m) return `${m[3].padStart(2, "0")}${({1:"JAN",2:"FEB",3:"MAR",4:"APR",5:"MAY",6:"JUN",7:"JUL",8:"AUG",9:"SEP",10:"OCT",11:"NOV",12:"DEC"} as Record<string,string>)[String(Number(m[2]))] ?? ""}`;
  m = raw.match(/^(\d{1,2})([A-Z]{3})(?:20)?\d{2}$/);
  if (m) return `${m[1].padStart(2, "0")}${m[2]}`;
  m = raw.match(/^([A-Z]{3})(\d{1,2})(?:20)?\d{2}$/);
  if (m) return `${m[2].padStart(2, "0")}${m[1]}`;
  return cleanDerivativeSymbol(raw.replace(/[^A-Z0-9]/g, ""));
}

export function normalizeOrder(raw: RawOrderModel): OrderModel {
  const buySell = String(raw.Buy_Sell ?? raw.buy_sell ?? "").trim();
  const side = buySell === "1" || buySell.toUpperCase() === "BUY" ? "BUY" : buySell === "2" || buySell.toUpperCase() === "SELL" ? "SELL" : undefined;
  
  const rawPrice = raw.order_price ?? raw.OrderPrice ?? raw.price ?? raw.traded_price ?? raw.tradedPrice;
  const price = Number(rawPrice) || 0;

  return {
    order_id: firstString(raw, ["order_id", "orderId", "OrderNumber", "oms_order_id", "local_order_id", "localOrderId", "LocalOrderID", "UniqueCode", "uniqueCode", "unique_code"]),
    exchange: firstString(raw, ["exchange", "exchange_segment", "exchangeSegment", "segment", "Exchange"]),
    exchange_order_no: firstString(raw, ["exchange_order_no", "exchangeOrderNo", "exchange_order_number", "OrderNumber"]) || undefined,
    scrip_token: firstNumber(raw, ["scrip_token", "scripToken", "token", "Token", "ScripCode"]) || undefined,
    trading_symbol: rawContractDisplaySymbol(raw),
    series: firstString(raw, ["series", "Series", "scrip_series"]) || undefined,
    transaction_type: (side || firstString(raw, ["transaction_type", "transactionType", "side"]) || "BUY").toUpperCase() as TransactionType,
    product_type: firstString(raw, ["product_type", "productType", "product", "Product"]),
    order_type: firstString(raw, ["order_type", "orderType", "OrderType"]),
    quantity: firstNumber(raw, ["total_quantity", "totalQuantity", "quantity", "qty", "OrderOriginalQty", "order_original_qty", "original_quantity", "originalQuantity"]),
    filled_quantity: firstNumber(raw, ["traded_quantity", "tradedQuantity", "filled_quantity", "filledQty", "TradedQTY", "tradedQty", "TradeQty"]),
    pending_quantity: firstNumber(raw, ["pending_quantity", "pendingQuantity", "open_quantity", "openQuantity", "PendingQty"]),
    disclosed_quantity: firstNumber(raw, ["disclosed_quantity", "disclosedQuantity", "disclosed_qty", "DQ"]),
    price,
    trigger_price: firstNumber(raw, ["trigger_price", "triggerPrice", "TriggerPrice"]),
    average_price: firstNumber(raw, ["average_price", "avg_price", "averagePrice", "traded_price", "TradedPrice"]),
    status: firstString(raw, ["status", "order_status", "orderStatus", "OrderStatus"]) || "PENDING",
    validity: firstString(raw, ["validity", "OrderValidity"]) || "DAY",
    validity_days: firstNumber(raw, ["validity_days", "validityDays", "gtd_days", "gtdDays", "Days"]),
    order_timestamp: firstString(raw, ["order_timestamp", "order_modified_timestamp", "OrderEntryTime", "LastModifiedTime", "order_time", "orderTime", "exchange_time", "created_at", "time"]),
    error_reason: firstString(raw, ["error_reason", "errorReason", "Reason"]),
    message: firstString(raw, ["error_reason", "errorReason", "message", "Reason"]),
    is_amo: [true, "true", "Y", "1", 1].includes(raw?.is_amo) || [true, "true", "Y", "1", 1].includes(raw?.isAmo),
    order_identifier: firstString(raw, ["order_identifier", "orderIdentifier", "UniqueCode", "uniqueCode", "unique_code", "client_order_identifier", "clientOrderIdentifier"]),
    gateway_order_no: firstString(raw, ["gateway_order_no", "gatewayOrderNo", "gateway_order_number", "gatewayOrderNumber"]),
    raw,
  };
}

/**
 * Broker list endpoints can return either a bare array or a response object
 * containing the rows under a feature-specific key. Keep the UI tolerant of
 * both shapes without changing the broker API contract.
 */
export function extractList<T = Record<string, any>>(value: unknown, keys: string[] = []): T[] {
  if (Array.isArray(value)) return value as T[];
  if (!value || typeof value !== "object") return [];
  const source = value as Record<string, unknown>;
  for (const key of keys) {
    const candidate = source[key];
    if (Array.isArray(candidate)) return candidate as T[];
  }
  for (const key of ["data", "result", "response"]) {
    const nested = source[key];
    if (nested && nested !== value) {
      const rows = extractList<T>(nested, keys);
      if (rows.length) return rows;
    }
  }
  return [];
}

/** Returns true only for an order that can still be working in the market. */
export function isOpenOrder(order: OrderModel): boolean {
  const status = String(order.status ?? "").trim().toUpperCase().replace(/[ _-]+/g, "");

  // Only these broker statuses represent an order that can still be working.
  // PENDING also covers pending/partially-filled orders.
  return ["PENDING", "OMSXMITTED", "EXXMITTED", "AMOACCEPTED"].includes(status);
}

export function normalizeTrade(raw: RawTradeModel): TradeModel {
  const buySell = String(raw.Buy_Sell ?? raw.buy_sell ?? "").trim();
  const side = buySell === "1" || buySell.toUpperCase() === "BUY" ? "BUY" : buySell === "2" || buySell.toUpperCase() === "SELL" ? "SELL" : undefined;

  const rawPrice = raw.TradedPrice ?? raw.trade_price ?? raw.tradePrice ?? raw.price;
  const price = raw.TradedPrice !== undefined && rawPrice != null ? Number(rawPrice) / 100 : Number(rawPrice) || 0;

  return {
    trade_id: firstString(raw, ["trade_no", "tradeNo", "trade_number", "TradeNumber", "trade_id", "exchange_trade_no", "exchangeTradeNo"]),
    order_id: firstString(raw, ["order_id", "orderId", "OrderNumber", "oms_order_id"]),
    exchange: firstString(raw, ["exchange", "exchange_segment", "exchangeSegment", "segment", "Exchange"]),
    exchange_order_no: firstString(raw, ["exchange_order_no", "exchangeOrderNo", "exchange_order_number", "OrderNumber"]) || undefined,
    scrip_token: firstNumber(raw, ["scrip_token", "scripToken", "token", "Token", "ScripCode"]) || undefined,
    trading_symbol: rawContractDisplaySymbol(raw),
    series: firstString(raw, ["series", "Series", "scrip_series"]) || undefined,
    transaction_type: (side || firstString(raw, ["transaction_type", "transactionType", "side"]) || "BUY").toUpperCase() as TransactionType,
    product_type: firstString(raw, ["product_type", "productType", "product", "Product"]) || undefined,
    order_type: firstString(raw, ["order_type", "orderType", "OrderType"]) || undefined,
    quantity: firstNumber(raw, ["trade_quantity", "tradeQuantity", "TradeQty", "quantity", "qty"]),
    price,
    trade_timestamp: firstString(raw, ["trade_timestamp", "tradeTimestamp", "trade_time", "TradeTime", "timestamp", "time"]),
    order_identifier: firstString(raw, ["order_identifier", "orderIdentifier", "UniqueCode", "uniqueCode", "unique_code", "client_order_identifier", "clientOrderIdentifier"]) || undefined,
    raw,
  };
}

/**
 * Ports InstrumentDisplayHelper.displayName's stock-case rule from
 * lib/features/market_watch/utils/instrument_display_helper.dart:
 * "RELIANCE EQ" (symbol + series), matching what the mobile app shows
 * everywhere — watchlist, order book, trade book. This also ports the
 * mobile contract builder for F&O and MCX instruments.
 */
export function isIndexInstrument(i: Partial<Instrument> | null | undefined): boolean {
  if (!i) return false;

  // The instrument-master flag is authoritative. Index futures/options can share
  // the underlying index symbol (e.g. NIFTY) but are tradable derivative contracts.
  if (typeof i.isIndex === "boolean") return i.isIndex;

  // If the explicit flag is absent, rely only on instrument classification;
  // never infer non-tradability from a symbol-name list.
  return classifyInstrument(i as Instrument) === "INDEX";
}

export function instrumentDisplayName(i: Partial<Instrument>): string {
  const canonical = i.canonicalTradingSymbol?.trim();
  const kind = classifyInstrument(i as Instrument);

  if (
    canonical &&
    (kind === "OPT" || kind === "FUT" || kind === "COMM") &&
    /(?:CE|PE|FUT)$/i.test(canonical)
  ) {
    return cleanDerivativeSymbol(canonical);
  }

  const symbol = i.symbol?.trim().toUpperCase() ?? "";
  const candidates = [i.tradingSymbol, i.companyName, i.displayName];
  const option = (i.optionType ?? "").trim().toUpperCase();
  const expiry = compactExpiry(i.expiryDateText, i.expiryDate);
  const strike = compactStrike(i.strikePrice);
  const looksLikeContract = (value: string) =>
    option === "CE" || option === "PE" ? /(?:CE|PE)$/.test(value.toUpperCase()) : /FUT|\d{2}[A-Z]{3}/.test(value.toUpperCase());

  // Derivative metadata must take precedence over the underlying's display name
  // (and any index flag), otherwise contracts collapse to just the root symbol.
  // Use the normalized instrument-master fields so this works across segments.
  if (symbol && expiry && kind === "OPT" && option && strike) {
    return cleanDerivativeSymbol(`${symbol}${expiry}${strike}${option}`);
  }
  if (symbol && expiry && (kind === "FUT" || kind === "COMM")) {
    return cleanDerivativeSymbol(`${symbol}${expiry}FUT`);
  }

  if (isIndexInstrument(i)) {
    const raw = (i.symbol || i.displayName || i.tradingSymbol || i.companyName || "").trim();
    return raw.replace(/\s+EQ$/i, "").trim() || "INDEX";
  }

  if (kind === "COMM") {
    for (const candidate of candidates) {
      const compact = (candidate ?? "").trim().toUpperCase().replace(/\s/g, "");
      const future = compact.match(/^([A-Z]+)(\d{2})(\d{2})(\d{2})FUT$/);
      if (future) return cleanDerivativeSymbol(`${future[1]}${future[2]}${monthCode(future[3])}FUT`);
      if (compact && looksLikeContract(compact)) return cleanDerivativeSymbol(compact);
    }
    const expiry = compactExpiry(i.expiryDateText, i.expiryDate);
    if (symbol && expiry) {
      if (option && compactStrike(i.strikePrice)) return cleanDerivativeSymbol(`${symbol}${expiry}${compactStrike(i.strikePrice)}${option}`);
      return cleanDerivativeSymbol(`${symbol}${expiry}FUT`);
    }
  }
  if (kind === "FUT" || kind === "OPT") {
    for (const candidate of candidates) {
      const value = (candidate ?? "").trim();
      if (value && value.toUpperCase() !== symbol && looksLikeContract(value)) return cleanDerivativeSymbol(value);
    }
    for (const part of (i.derivativeDesc ?? "").split("--")) {
      if (looksLikeContract(part.trim())) return cleanDerivativeSymbol(part.trim());
    }
  }
  // The `symbol` field is reliably a short ticker across everything seen so
  // far. `tradingSymbol` (sourced from sSecurityDesc/security_desc in the
  // broker's search results) turned out to hold the FULL COMPANY NAME for
  // this broker's real data ("RELIANCE INDUSTRIES LTD", not "RELIANCE EQ")
  // — so it's only used as a last resort, never preferred over `symbol`.
  if (i.symbol?.trim()) {
    return i.series?.trim() ? `${i.symbol.trim()} ${i.series.trim()}` : i.symbol.trim();
  }
  if (i.tradingSymbol?.trim()) return cleanDerivativeSymbol(i.tradingSymbol.trim());
  return "";
}

function monthCode(value: string): string {
  return ({ "01": "JAN", "02": "FEB", "03": "MAR", "04": "APR", "05": "MAY", "06": "JUN", "07": "JUL", "08": "AUG", "09": "SEP", "10": "OCT", "11": "NOV", "12": "DEC" } as Record<string, string>)[value] ?? "";
}

function compactExpiry(value: string | undefined, expiryDate?: number): string {
  // Prefer the actual expiry date so weekly contracts do not collapse into a month-only label.
  const date = Number(expiryDate);
  if (Number.isInteger(date) && date >= 19000101 && date <= 21001231) {
    const year = Math.floor(date / 10000);
    const month = Math.floor((date % 10000) / 100);
    const day = date % 100;
    if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
      const monthNames = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"];
      const expiryWeekday = new Date(Date.UTC(year, month - 1, day)).getUTCDay();
      // NIFTY monthly expiry is the last Tuesday of the month; weekly contracts
      // need their actual day so they don't all display as NIFTY26NOV.
      let lastTuesday = new Date(Date.UTC(year, month, 0));
      while (lastTuesday.getUTCDay() !== expiryWeekday) lastTuesday.setUTCDate(lastTuesday.getUTCDate() - 1);
      const isMonthEndExpiry = day === lastTuesday.getUTCDate() && expiryWeekday === 2;
      return isMonthEndExpiry
        ? `${String(year).slice(-2)}${monthNames[month - 1]}`
        : `${String(day).padStart(2, "0")}${monthNames[month - 1]}`;
    }
  }
  const raw = (value ?? "").trim().toUpperCase();
  const full = raw.match(/(\\d{1,2})[\\s-]?([A-Z]{3})[\\s-]?(\\d{4})/);
  if (full) return `${full[3].slice(2)}${full[2]}`;
  const short = raw.match(/([A-Z]{3})(\\d{2})/);
  if (short) return `${short[2]}${short[1]}`;
  const numeric = raw.match(/^(\\d{4})(\\d{2})(\\d{2})$/);
  if (numeric) return compactExpiry(undefined, Number(raw));
  return cleanDerivativeSymbol(raw.replace(/[^A-Z0-9]/g, ""));
}

function compactStrike(value: string | undefined): string {
  const number = Number((value ?? "").replace(/,/g, ""));
  if (!Number.isFinite(number) || number <= 0) return "";
  const normalized = number / 100;
  return Number.isInteger(normalized) ? String(normalized) : String(normalized).replace(/\.0+$/, "");
}

/** Same MCX/F&O metadata line shown by the Flutter symbol search. */
export function instrumentSearchSubtitle(i: Instrument): string {
  if (isIndexInstrument(i)) return i.exchangeSegment || i.exchange || "INDEX";
  const kind = classifyInstrument(i);
  const isMcx = (i.exchangeSegment ?? i.exchange).toUpperCase().includes("MCX");
  const parts = [i.exchange];
  if (isMcx && (kind === "FUT" || kind === "OPT" || kind === "COMM")) {
    if (i.expiryDateText) parts.push(`Expiry: ${i.expiryDateText}`);
    if (kind === "OPT" && i.strikePrice) parts.push(`${compactStrike(i.strikePrice) || i.strikePrice} ${(i.optionType ?? "").toUpperCase()}`.trim());
  } else {
    if (i.series) parts.push(i.series);
    if (i.companyName && i.companyName !== i.tradingSymbol) parts.push(i.companyName);
  }
  if (!i.isIndex && (i.regularLot ?? 0) > 1) parts.push(`Lot ${i.regularLot}`);
  return parts.filter(Boolean).join(" · ");
}

export function searchFilters(results: Instrument[]): (InstrumentKind | "ALL" | string)[] {
  return ["ALL", "STOCK", "INDEX", "FUT", "OPT", "COMM", "CUR", ...Array.from(new Set(results.map((i) => i.exchange.toUpperCase()).filter(Boolean))).sort()];
}

/** Mobile SearchSymbolScreen ordering: exact/prefix matches first, then family, expiry and exchange. */
export function sortSearchInstruments(results: Instrument[], query: string, filter: InstrumentKind | "ALL" | string): Instrument[] {
  const text = query.trim().toUpperCase();
  const filtered = results.filter((i) => filter === "ALL" || classifyInstrument(i) === filter || i.exchange.toUpperCase() === filter);
  const score = (i: Instrument) => {
    const values = [i.symbol, i.tradingSymbol, i.displayName, instrumentDisplayName(i), i.companyName].map((v) => (v ?? "").toUpperCase());
    if (values.slice(0, 3).some((v) => v === text)) return 0;
    if (values[0].startsWith(text)) return 10;
    if (values.slice(1, 3).some((v) => v.startsWith(text))) return 14;
    if (values.slice(0, 3).some((v) => v.includes(text))) return 30;
    return values[4].includes(text) ? 42 : 70;
  };
  const family = (i: Instrument) => ({ INDEX: 0, STOCK: 1, FUT: 2, OPT: 3, COMM: 4, CUR: 5, OTHER: 6 })[classifyInstrument(i)];
  const seen = new Set<string>();
  return [...filtered]
    .sort((a, b) => score(a) - score(b) || family(a) - family(b) || (a.expiryDate ?? Number.MAX_SAFE_INTEGER) - (b.expiryDate ?? Number.MAX_SAFE_INTEGER) || instrumentDisplayName(a).localeCompare(instrumentDisplayName(b)))
    .filter((i) => {
      const key = `${i.exchangeSegment ?? i.exchange}|${i.token}|${instrumentDisplayName(i)}|${i.expiryDate ?? ""}|${i.strikePrice ?? ""}|${i.optionType ?? ""}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
}

/** Composed "SYMBOL SERIES" display for order/trade rows, e.g. "RELIANCE EQ". */
export function positionDisplaySymbol(p: { symbol?: string; exchange?: string; preferred_exchange?: string; instrument?: string; expiry_date?: string; strike_price?: string; option_type?: string }): string {
  const segment = String(p.preferred_exchange || p.exchange || '').toUpperCase();
  const instrument = String(p.instrument || '').toUpperCase();
  const derivative = isDerivativeMarketSegment(segment) || /(?:FUT|OPT)/.test(instrument);
  const base = String(p.symbol || '').trim();
  if (!derivative) return base || '—';
  const rawExpiry = String(p.expiry_date || '').trim().toUpperCase();
  let expiry = compactDerivativeExpiry(rawExpiry);
  const option = String(p.option_type || '').trim().toUpperCase();
  const strike = String(p.strike_price || '').replace(/,/g, '');
  if (base && expiry) {
    if ((option === 'CE' || option === 'PE') && strike) return cleanDerivativeSymbol(`${base}${expiry}${strike}${option}`);
    return cleanDerivativeSymbol(`${base}${expiry}FUT`);
  }
  return base || '—';
}

export function orderDisplaySymbol(o: { trading_symbol: string; series?: string; exchange: string }): string {
  const symbol = String(o.trading_symbol ?? "").trim();
  const exchange = String(o.exchange ?? "").trim().toUpperCase();
  const derivative = isDerivativeMarketSegment(exchange) || /(?:FUT|CE|PE)$/.test(symbol.toUpperCase());

  // Series is a cash-equity attribute. Never append values such as XX to
  // an already-complete derivative contract symbol.
  if (derivative) return cleanDerivativeSymbol(symbol) || "—";

  return (
    instrumentDisplayName({
      symbol,
      series: o.series,
      tradingSymbol: symbol,
      exchangeSegment: exchange,
    }) || symbol
  );
}

/**
 * Ports RegularOrderRequest.toJson() from
 * lib/features/orders/models/regular_order_request.dart exactly — the
 * broker expects a nested `scrip_info` object and order_type codes
 * "RL"/"RL-MKT"/"SL"/"SL-MKT" (NOT "MARKET"/"LIMIT").
 */
export type OrderKind = "LIMIT" | "MARKET" | "SL_LIMIT" | "SL_MARKET";

const ORDER_KIND_CODE: Record<OrderKind, string> = {
  LIMIT: "RL",
  MARKET: "RL-MKT",
  SL_LIMIT: "SL",
  SL_MARKET: "SL-MKT",
};

export function orderKindRequiresLimitPrice(kind: OrderKind): boolean {
  return kind === "LIMIT" || kind === "SL_LIMIT";
}
export function orderKindRequiresTriggerPrice(kind: OrderKind): boolean {
  return kind === "SL_LIMIT" || kind === "SL_MARKET";
}

export interface BuildOrderParams {
  instrument: Instrument;
  side: TransactionType;
  productType: ProductType;
  orderKind: OrderKind;
  quantity: number;
  price: number;
  triggerPrice?: number;
  disclosedQuantity?: number;
  validity?: Validity;
  validityDays?: number;
  isAmo?: boolean;
}

export function buildOrderPayload(p: BuildOrderParams) {
  const segment = exchangeSegmentFor(p.instrument);
  const instrumentName = (p.instrument.instrumentName ?? "").toUpperCase();
  const isDerivative =
    segment.includes("FO") ||
    segment.includes("COMM") ||
    segment.includes("CUR") ||
    instrumentName.includes("FUT") ||
    instrumentName.includes("OPT") ||
    Boolean((p.instrument.optionType ?? "").trim()) ||
    Boolean((p.instrument.expiryDateText ?? "").trim());
  const symbol = isDerivative
    ? cleanDerivativeSymbol(
        p.instrument.canonicalTradingSymbol ||
        p.instrument.tradingSymbol ||
        p.instrument.symbol ||
        instrumentDisplayName(p.instrument)
      )
    : (
        p.instrument.symbol ||
        p.instrument.tradingSymbol ||
        instrumentDisplayName(p.instrument)
      );
  return {
    scrip_info: {
      exchange: exchangeSegmentFor(p.instrument) || p.instrument.exchange,
      scrip_token: Number(p.instrument.token) || 0,
      symbol,
      series: p.instrument.series ?? "",
      expiry_date: p.instrument.expiryDateText ?? "",
      strike_price: p.instrument.strikePrice ?? "",
      option_type: p.instrument.optionType ?? "",
    },
    transaction_type: p.side,
    // UI labels are mapped to the broker's actual product values.
    product_type: ({
      CNC: "DELIVERY",
      MIS: "INTRADAY",
      NRML: isDerivativeMarketSegment(segment) ? "DELIVERY" : "CARRYFORWARD",
      CO: "COVER",
      BO: "BRACKET",
    } as const)[p.productType],
    order_type: ORDER_KIND_CODE[p.orderKind],
    quantity: p.quantity,
    price: orderKindRequiresLimitPrice(p.orderKind) ? p.price : 0,
    trigger_price: p.triggerPrice ?? 0,
    disclosed_quantity: p.disclosedQuantity ?? 0,
    validity: validityToApi(p.validity ?? "DAY", segment),
    validity_days: p.validityDays ?? 0,
    is_amo: p.isAmo ?? false,
    order_identifier: "",
    part_code: "",
    algo_id: "",
    strategy_id: "",
    vender_code: "",
  };
}

/** Builds the "marketSegmentId_scripToken" key subscribeTouchline expects. */
export function feedToken(i: Instrument): string | null {
  const segmentId = i.marketSegmentId ?? Object.entries(SEGMENT_ID_TO_EXCHANGE).find(
    ([, seg]) => seg === (i.exchangeSegment ?? "").toUpperCase()
  )?.[0];
  if (!segmentId || !i.token) return null;
  return `${segmentId}_${i.token}`;
}

export interface BrokerMessageModel {
  MsgSrNo: number;
  SendMsgTime: string;
  Subject: string;
  Message: string;
  MsgType: string;
}

export interface OrderMessageModel {
  time: string;
  date: string;
  cliOrdNo: string;
  msg: string;
  mktSegId: number;
}

export interface ExchangeMessageModel {
  SegmentId: number;
  Time: string;
  Messages: string;
}

export interface RecommendationModel {
  sRecoTag: string;
  sRecoId: string;
  sScripDesc: string;
  nMarketSegmentId: number;
  nToken: number;
  nRecoType: number;
  sRecoDetails: string;
  sSecurityDesc: string;
  sSource: number;
  ID: string;
  LastModify: string;
  nTotalNoRecords: number;
  nExpiryDate: string;
}