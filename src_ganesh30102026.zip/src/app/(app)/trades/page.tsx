"use client";

import { Badge, Card, EmptyState } from "@/components/ui/Primitives";
import { LIVE_TRADES, usePolledData } from "@/hooks/usePolledData";
import { tradeBookPath } from "@/lib/endpoints";
import { formatCurrency } from "@/lib/format";
import { extractList, normalizeTrade, orderDisplaySymbol, type RawTradeModel } from "@/types/trading";

export default function TradesPage() {
  const trades = usePolledData<RawTradeModel>(tradeBookPath(1, 100), 10_000, true, LIVE_TRADES);
  const rows = extractList<RawTradeModel>(trades.data, ["trades", "tradeBook", "trade_book", "items", "records"]).map(normalizeTrade);

  return (
    <div className="space-y-4">
      <h1 className="text-xl font-semibold">Trade Book</h1>
      <Card className="overflow-x-auto p-0">
        {trades.loading ? (
          <p className="p-6 text-xs text-aveon-muted">Loading trades…</p>
        ) : rows.length === 0 ? (
          <EmptyState title="No trades today" />
        ) : (
          <table className="w-full text-sm">
            <thead className="border-b border-aveon-border text-left text-xs text-aveon-muted">
              <tr>
                <th className="px-4 py-3">Symbol</th>
                <th className="px-4 py-3">Side</th>
                <th className="px-4 py-3 text-right">Qty</th>
                <th className="px-4 py-3 text-right">Price</th>
                <th className="px-4 py-3">Trade ID</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((t) => (
                <tr key={t.trade_id} className="table-row-hover border-b border-aveon-border/50">
                  <td className="px-4 py-3">{orderDisplaySymbol(t)}</td>
                  <td className="px-4 py-3">
                    <Badge tone={t.transaction_type === "BUY" ? "buy" : "sell"}>{t.transaction_type}</Badge>
                  </td>
                  <td className="px-4 py-3 text-right">{t.quantity}</td>
                  <td className="px-4 py-3 text-right">{formatCurrency(t.price)}</td>
                  <td className="px-4 py-3 text-xs text-aveon-muted">{t.trade_id}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
