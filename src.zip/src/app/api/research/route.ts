import { NextRequest, NextResponse } from "next/server";
// Import your preferred client or fetch Google's Gemini / Vertex AI endpoints securely server-side

export async function POST(req: NextRequest) {
  try {
    const { query, symbol } = await req.json();

    if (!query) {
      return NextResponse.json({ success: false, message: "Query is required." }, { status: 400 });
    }

    // Example server-side call to Google GenAI / Gemini API
    // Keeping your keys completely hidden from the browser bundle
    const aiResponse = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${process.env.GEMINI_API_KEY}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        contents: [{
          parts: [{ text: `Act as a senior quantitative financial analyst. Provide a concise, structured research breakdown for ${symbol || "market query"}: ${query}` }]
        }]
      })
    });

    const data = await aiResponse.json();
    const insight = data?.candidates?.[0]?.content?.parts?.[0]?.text || "No insights generated.";

    return NextResponse.json({ success: true, insight });
  } catch (error) {
    return NextResponse.json({ success: false, message: "Research synthesis failed." }, { status: 500 });
  }
}