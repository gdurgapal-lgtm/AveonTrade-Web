"use client";

import { useState } from "react";
import { Sparkles, Edit3, CheckSquare, Search, Send, ArrowRight } from "lucide-react";
import { Button, Input, Card } from "@/components/ui/Primitives";

interface GoogleStyleResearchSidebarProps {
  userName?: string;
  activeSymbol?: string;
}

export default function GoogleStyleResearchSidebar({ userName = "Ganesh", activeSymbol = "MARKET" }: GoogleStyleResearchSidebarProps) {
  const [query, setQuery] = useState("");
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Array<{ role: 'user' | 'assistant'; text: string }>>([]);

  const suggestions = [
    `How is ${activeSymbol} performing today?`,
    "Which holdings have the highest overall return?",
    "Show me risk metrics and ATR volatility targets.",
  ];

  async function handleSend(customPrompt?: string) {
    const textToSend = customPrompt || query;
    if (!textToSend.trim()) return;

    const newMessages = [...messages, { role: 'user' as const, text: textToSend }];
    setMessages(newMessages);
    if (!customPrompt) setQuery("");
    setLoading(true);

    try {
      const res = await fetch("/api/research", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: textToSend, symbol: activeSymbol }),
      });
      const data = await res.json();
      setMessages([...newMessages, { role: 'assistant', text: data.insight || data.message || "Analysis complete." }]);
    } catch {
      setMessages([...newMessages, { role: 'assistant', text: "Failed to connect to research service." }]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="w-80 h-full flex flex-col border-l border-aveon-border bg-aveon-panel font-mono text-xs select-none">
      {/* Sidebar Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-aveon-border">
        <h3 className="font-bold text-aveon-text text-sm">Research</h3>
        <div className="flex items-center gap-2 text-aveon-muted">
          <Sparkles size={15} className="text-aveon-primary" />
        </div>
      </div>

      {/* Main Scrollable Area */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {messages.length === 0 ? (
          <>
            {/* Greeting */}
            <div>
              <p className="text-sm font-semibold text-aveon-text">Hi {userName}, ask any financial question</p>
            </div>

            {/* Suggestion Chips / Prompts */}
            <div className="space-y-2">
              {suggestions.map((suggestion, idx) => (
                <button
                  key={idx}
                  onClick={() => handleSend(suggestion)}
                  className="w-full text-left p-2.5 rounded-lg border border-aveon-border bg-aveon-panel2 text-aveon-muted hover:text-aveon-text hover:border-aveon-primary transition flex items-center justify-between group"
                >
                  <span>{suggestion}</span>
                  <ArrowRight size={13} className="opacity-0 group-hover:opacity-100 text-aveon-primary transition" />
                </button>
              ))}
            </div>

            {/* Explore Section */}
            <div className="pt-2">
              <p className="text-[11px] font-medium text-aveon-muted mb-2">Explore what's possible</p>
              <div className="space-y-1.5">
                <button className="w-full flex items-center gap-2.5 p-2 rounded-md border border-aveon-border bg-aveon-panel hover:bg-aveon-panel2 text-aveon-text transition">
                  <Edit3 size={14} className="text-aveon-primary" />
                  <span>Edit watchlist / portfolio</span>
                </button>
                <button className="w-full flex items-center gap-2.5 p-2 rounded-md border border-aveon-border bg-aveon-panel hover:bg-aveon-panel2 text-aveon-text transition">
                  <CheckSquare size={14} className="text-aveon-primary" />
                  <span>Create trading task</span>
                </button>
                <button className="w-full flex items-center gap-2.5 p-2 rounded-md border border-aveon-border bg-aveon-panel hover:bg-aveon-panel2 text-aveon-text transition">
                  <Search size={14} className="text-aveon-primary" />
                  <span>Deep AI Market Search</span>
                </button>
              </div>
            </div>
          </>
        ) : (
          <div className="space-y-3">
            {messages.map((m, i) => (
              <div key={i} className={`p-3 rounded-lg ${m.role === 'user' ? 'bg-aveon-panel2 text-aveon-text ml-4' : 'bg-aveon-primary/10 border border-aveon-primary/30 text-aveon-text mr-4'}`}>
                <p className="text-[10px] font-bold text-aveon-muted mb-1">{m.role === 'user' ? 'You' : 'Aveon Copilot'}</p>
                <p className="leading-relaxed whitespace-pre-wrap">{m.text}</p>
              </div>
            ))}
            {loading && <p className="text-aveon-muted animate-pulse">Synthesizing research insights…</p>}
          </div>
        )}
      </div>

      {/* Bottom Input Bar (Matches Google Finance Ask Box) */}
      <div className="p-3 border-t border-aveon-border bg-aveon-panel2">
        <div className="relative flex items-center">
          <input
            type="text"
            placeholder="Ask anything"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            className="w-full rounded-full border border-aveon-border bg-aveon-panel py-2 pl-3 pr-10 text-xs text-aveon-text outline-none focus:border-aveon-primary"
          />
          <button
            onClick={() => handleSend()}
            disabled={loading || !query.trim()}
            className="absolute right-1.5 p-1.5 rounded-full bg-aveon-primary text-white hover:opacity-90 disabled:opacity-40 transition"
          >
            <Send size={12} />
          </button>
        </div>
      </div>
    </div>
  );
}