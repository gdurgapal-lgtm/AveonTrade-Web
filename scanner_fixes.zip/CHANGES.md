# AI Scanner – review & fixes

Drop-in: copy the files under `src/` over your project (5 files). `test/engine.test.ts` is optional
(run with `npx tsx test/engine.test.ts`; it needs `typescript` + `tsx`).

## Bugs fixed (correctness)
1. **Analyze dialog used 1-minute bars while labelled 15m/1h** – EMA/ATR/support/resistance were wrong. Now uses the same resampled bars as the scan.
2. **Analyze dialog title showed the wrong symbol** (used the chart-popup symbol).
3. **Candle cache never expired** – history was loaded once; EMAs/RSI froze while only LTP moved. Now refreshes (45 s intraday / 5 min daily, tail-only merge) and the forming bar follows live price.
4. **EMA crossover was wrong** (compared previous *price* to EMA21). Now true EMA9/21 cross within last 3 bars.
5. **RSI/ATR were simple averages** – didn't match broker/TradingView. Now Wilder.
6. **Volume ratio used a half-formed bar vs full-bar average** – now projected to a full bar.
7. **Category could contradict side** (e.g. BULLISH_BREAKOUT on a SELL) and "RSI_REVERSAL" was just a fallback label. Now side-consistent; real "RSI pullback turn" detection; new "Trend Continuation".
8. **Derivatives with missing lot size were sized as 1 unit** – now rejected.
9. **Chart-history errors were swallowed** (route returns HTTP 200 + success:false) – real message now shown per symbol.
10. **Risk input couldn't be typed** (clamped to 500 on every keystroke). Min is now ₹100, commits on blur/Enter.
11. **Freshness gate accepted 7-day-old intraday data** – now session-aware (≈15 min while market open).
12. **Fixed 10 % LTP gate blocked legit daily movers** – 7 % intraday / 20 % daily.
13. `/api/ai/analyze-technicals`: no real auth, printed `₹undefined`, fake "AI". Now authenticated, validated, deterministic (labelled rule-based). Route is still not called from the UI.

## Performance
- Original re-ran resample + `toLocaleDateString` for every candle of every symbol on **every quote flush (≤10×/s): ~860 ms per pass** (50 symbols).
- Now: series prepared once per history load (cached), scan runs **1×/s at ~3 ms**. 
- History shared across 5m/15m/1h (no refetch when switching), progressive load, refresh fetches only the tail, bounded memory, retries with back-off.
- Removed per-request response logging in chart-history.

## Added
- Live bar overlay, hold + 2-scan confirm (no flicker), NEW badge + "since" time, optional sound alert.
- Trade plan: tick-rounded levels, swing-aware stop (1.5–2.5 ATR), room-adjusted R:R, position value, max-qty cap, qty-0 explanation, risk flags (extended, overbought, wide stop, low volume, resistance close, short-sell = MIS).
- Short sells pre-select MIS in the order ticket.
- Scan-health bar (history/quotes/signals/timestamps, reasons for no-signal, per-symbol data issues), market open/closed chip.
- Min-score filter; settings persisted (watchlist, timeframe, risk, min score, sound).
