import assert from "node:assert/strict";
import { evaluateInstrument, getScannerCandleFreshness, isMarketOpen, prepareSeries, type ScannerCandle } from "../src/lib/aiScannerEngine";
import type { Instrument } from "../src/types/trading";

const IST = 330 * 60_000, DAY = 86_400_000;
const inst = (over: Partial<Instrument> = {}): Instrument => ({
  exchange: "NSE", token: "1", symbol: "TEST", tradingSymbol: "TEST", companyName: "Test", exchangeSegment: "NSE_EQ",
  instrumentName: "EQUITY", series: "EQ", priceTick: 0.05, regularLot: 1, ...over,
} as Instrument);

// deterministic RNG
let seed = 42;
const rnd = () => ((seed = (seed * 1664525 + 1013904223) % 4294967296) / 4294967296);
const gauss = () => Math.sqrt(-2 * Math.log(rnd() + 1e-12)) * Math.cos(2 * Math.PI * rnd());

/** 1-minute candles for `days` weekdays before `nowMs`'s day plus today up to nowMs. */
function gen(nowMs: number, days: number, drift: number, tail?: { mins: number; drift: number; volMult: number }): ScannerCandle[] {
  const out: ScannerCandle[] = [];
  const today = Math.floor((nowMs + IST) / DAY);
  let px = 1000;
  const dayList: number[] = [];
  for (let d = today - 20; d <= today; d++) {
    const dow = new Date(d * DAY).getUTCDay();
    if (dow !== 0 && dow !== 6) dayList.push(d);
  }
  const use = dayList.slice(-(days + 1));
  for (const d of use) {
    const open = d * DAY - IST + (9 * 60 + 15) * 60_000;
    for (let m = 0; m < 375; m++) {
      const t = open + m * 60_000;
      if (t > nowMs) break;
      const minsLeft = (nowMs - t) / 60_000;
      const inTail = tail && minsLeft <= tail.mins;
      const dr = inTail ? tail!.drift : drift;
      const o = px;
      const c = o * (1 + dr + gauss() * 0.0004);
      const h = Math.max(o, c) * (1 + Math.abs(gauss()) * 0.0003);
      const l = Math.min(o, c) * (1 - Math.abs(gauss()) * 0.0003);
      const v = Math.round((8000 + rnd() * 4000) * (inTail ? tail!.volMult : 1));
      out.push({ O: o, H: h, L: l, C: c, V: v, DT: new Date(t).toISOString() });
      px = c;
    }
  }
  return out;
}

// Thursday 5 Nov 2026, 11:07:30 IST (market open)
const NOW = Date.parse("2026-11-05T11:07:30+05:30");
let passed = 0;
const test = (name: string, fn: () => void) => { fn(); passed++; console.log("  ✓", name); };

console.log("engine tests");

test("market hours helper", () => {
  assert.equal(isMarketOpen(NOW), true);
  assert.equal(isMarketOpen(Date.parse("2026-11-05T09:10:00+05:30")), false);
  assert.equal(isMarketOpen(Date.parse("2026-11-05T15:30:00+05:30")), false);
  assert.equal(isMarketOpen(Date.parse("2026-11-07T11:00:00+05:30")), false); // Saturday
});

const up = gen(NOW, 9, 0.00012, { mins: 25, drift: 0.0009, volMult: 3 });
const last = up[up.length - 1];

test("hourly bars are aligned to 09:15 and 5m series are deduped/sorted", () => {
  const shuffled = [...up, up[10], up[500]].sort(() => rnd() - 0.5);
  const s = prepareSeries(shuffled, "5m");
  for (let i = 1; i < s.bars.length; i++) assert.ok(s.bars[i].t > s.bars[i - 1].t);
  const h = prepareSeries(up, "1h");
  const first = new Date(h.bars[h.bars.length - 1].t + IST);
  assert.equal(first.getUTCMinutes(), 15, "1h bucket should start at :15");
  console.log("     1m candles:", up.length, "| 5m:", s.bars.length, "| 15m:", prepareSeries(up, "15m").bars.length, "| 1h:", h.bars.length);
});

test("Wilder RSI/ATR/EMA match an independent reference", () => {
  const s = prepareSeries(up, "15m").bars;
  const ev = evaluateInstrument(inst(), up, "15m", 2500, last.C, NOW);
  assert.ok(ev.analysis, "analysis present");
  // independent reference on the same bars (live overlay replaces last close with ltp == last 1m close)
  const closes = s.map((b) => b.C);
  closes[closes.length - 1] = last.C;
  const alpha = 1 / 14;
  let ag = 0, al = 0;
  for (let i = 1; i <= 14; i++) { const d = closes[i] - closes[i - 1]; ag += Math.max(d, 0); al += Math.max(-d, 0); }
  ag /= 14; al /= 14;
  for (let i = 15; i < closes.length; i++) { const d = closes[i] - closes[i - 1]; ag = ag * (1 - alpha) + Math.max(d, 0) * alpha; al = al * (1 - alpha) + Math.max(-d, 0) * alpha; }
  const refRsi = 100 - 100 / (1 + ag / al);
  assert.ok(Math.abs(refRsi - ev.analysis!.rsi14) < 0.01, `RSI ${ev.analysis!.rsi14} vs ref ${refRsi}`);
  let e = closes.slice(0, 20).reduce((a, b) => a + b, 0) / 20;
  for (let i = 20; i < closes.length; i++) e = closes[i] * (2 / 21) + e * (1 - 2 / 21);
  assert.ok(Math.abs(e - ev.analysis!.ema20) < 1e-9, "EMA20");
  console.log(`     RSI ${ev.analysis!.rsi14.toFixed(2)} (ref ${refRsi.toFixed(2)}) | ATR ${ev.analysis!.atr14.toFixed(3)}`);
});

test("uptrend + volume breakout => BUY signal with sane, tick-aligned plan", () => {
  const ev = evaluateInstrument(inst(), up, "15m", 2500, last.C, NOW);
  assert.ok(ev.signal, `expected signal, got reject=${ev.reject} ${ev.rejectDetail ?? ""}`);
  const p = ev.signal!.tradePlan;
  assert.equal(p.side, "BUY");
  assert.ok(p.stopLoss < last.C && p.target1 > last.C && p.target2 > p.target1);
  for (const v of [p.stopLoss, p.target1, p.target2]) assert.ok(Math.abs(v / 0.05 - Math.round(v / 0.05)) < 1e-6, `tick-aligned ${v}`);
  assert.ok(p.riskAmount <= 2500 + 1e-6, "never risks more than budget");
  assert.ok(p.suggestedQty > 0);
  assert.ok(Math.abs(p.positionValue - p.suggestedQty * p.entryZoneMin) < p.suggestedQty * 2, "position value sensible");
  console.log(`     ${ev.signal!.signalType} ${ev.signal!.categoryLabel} score ${ev.signal!.confidence} | entry ${last.C.toFixed(2)} SL ${p.stopLoss} T1 ${p.target1} qty ${p.suggestedQty} risk ₹${p.riskAmount} rr ${p.riskRewardRatio}`);
  console.log(`     flags: ${ev.signal!.riskFlags.join("; ") || "none"}`);
});

test("downtrend mirror => SELL, category consistent with side", () => {
  seed = 7;
  const dn = gen(NOW, 9, -0.00012, { mins: 25, drift: -0.0009, volMult: 3 });
  const l = dn[dn.length - 1];
  const ev = evaluateInstrument(inst(), dn, "15m", 2500, l.C, NOW);
  assert.ok(ev.signal, `reject=${ev.reject}`);
  assert.equal(ev.signal!.tradePlan.side, "SELL");
  assert.ok(ev.signal!.tradePlan.stopLoss > l.C && ev.signal!.tradePlan.target1 < l.C);
  assert.notEqual(ev.signal!.category, "BULLISH_BREAKOUT");
  assert.ok(ev.signal!.riskFlags.some((f) => f.includes("MIS")), "short-sell MIS warning present");
});

test("stale intraday history is rejected while market is open", () => {
  const stale = up.filter((c) => Date.parse(c.DT) < NOW - 60 * 60_000);
  const ev = evaluateInstrument(inst(), stale, "5m", 2500, last.C, NOW);
  assert.equal(ev.reject, "STALE_HISTORY");
  assert.equal(ev.signal, null);
});

test("live price keeps the forming bar current even when history lags by a bar", () => {
  const lag = up.filter((c) => Date.parse(c.DT) < NOW - 6 * 60_000); // history 6 min behind
  const ev = evaluateInstrument(inst(), lag, "5m", 2500, last.C, NOW);
  assert.notEqual(ev.reject, "STALE_HISTORY");
  assert.equal(ev.analysis?.ltp, last.C);
});

test("absurd live price vs history is blocked (bad tick)", () => {
  const ev = evaluateInstrument(inst(), up, "15m", 2500, last.C * 1.2, NOW);
  assert.equal(ev.reject, "LTP_DEVIATION");
});

test("derivative without lot size is rejected, with lot size is sized in lots", () => {
  const fut = inst({ instrumentName: "FUTSTK", exchangeSegment: "NSE_FO", regularLot: undefined });
  assert.equal(evaluateInstrument(fut, up, "15m", 2500, last.C, NOW).reject, "NO_LOT_SIZE");
  const fut2 = inst({ instrumentName: "FUTSTK", exchangeSegment: "NSE_FO", regularLot: 250 });
  const ev = evaluateInstrument(fut2, up, "15m", 400000, last.C, NOW);
  assert.ok(ev.signal);
  assert.equal(ev.signal!.tradePlan.suggestedQty % 250, 0);
});

test("risk budget smaller than one share/lot => qty 0 with explanation", () => {
  const ev = evaluateInstrument(inst(), up, "15m", 1, last.C, NOW);
  assert.ok(ev.signal);
  assert.equal(ev.signal!.tradePlan.suggestedQty, 0);
  assert.ok(ev.signal!.riskFlags.some((f) => f.includes("exceeds your risk")));
});

test("market closed (Saturday): signals flagged, no live overlay", () => {
  const sat = Date.parse("2026-11-07T11:00:00+05:30");
  const ev = evaluateInstrument(inst(), up, "15m", 2500, last.C, sat);
  assert.ok(ev.signal || ev.reject);
  if (ev.signal) assert.ok(ev.signal.riskFlags.some((f) => f.includes("Market closed")));
  assert.equal(getScannerCandleFreshness(up, "15m", Date.parse("2026-11-15T11:00:00+05:30")).fresh, false);
});

test("garbage candles never throw", () => {
  const junk: ScannerCandle[] = [{ O: NaN, H: 1, L: 2, C: 0, V: -5, DT: "not a date" }, ...up.slice(0, 100)];
  assert.doesNotThrow(() => evaluateInstrument(inst(), junk, "15m", 2500, 100, NOW));
  assert.equal(evaluateInstrument(inst(), [], "15m", 2500, 100, NOW).reject, "NO_HISTORY");
});

test("performance: 50 symbols, cold vs warm", () => {
  const sets = Array.from({ length: 50 }, (_, i) => { seed = 100 + i; return gen(NOW, 9, 0.0001, { mins: 25, drift: 0.0008, volMult: 2.5 }); });
  let t0 = performance.now();
  sets.forEach((c) => evaluateInstrument(inst(), c, "15m", 2500, c[c.length - 1].C, NOW));
  const cold = performance.now() - t0;
  t0 = performance.now();
  for (let r = 0; r < 10; r++) sets.forEach((c) => evaluateInstrument(inst(), c, "15m", 2500, c[c.length - 1].C, NOW));
  const warm = (performance.now() - t0) / 10;
  console.log(`     cold (resample+eval) ${cold.toFixed(0)} ms | warm scan of 50 symbols ${warm.toFixed(1)} ms`);
  assert.ok(warm < 150);
});

console.log(`\n${passed} tests passed`);
