"use client";

import { create } from "zustand";
import { normalizeOrder, isOpenOrder, normalizeTrade, type OrderModel, type TradeModel, type RawOrderModel, type RawTradeModel } from "@/types/trading";

interface LiveOrderState {
  orders: OrderModel[];
  trades: TradeModel[];
  initialized: boolean;
  setOrders: (orders: OrderModel[]) => void;
  setTrades: (trades: TradeModel[]) => void;
  upsertOrder: (raw: RawOrderModel) => void;
  addTrade: (raw: RawTradeModel) => void;
  reset: () => void;
}

export const useLiveOrderStore = create<LiveOrderState>((set) => ({
  orders: [],
  trades: [],
  initialized: false,
  
  setOrders: (newOrders) => set((state) => {
    const normalized = newOrders.map(normalizeOrder);
    
    // Explicitly keep only orders that are verified open AND have valid pending quantities
    const activeOrders = normalized.filter((o) => {
      const isOpen = isOpenOrder(o);
      const pendingQty = o.pending_quantity ?? Math.max(0, o.quantity - (o.filled_quantity ?? 0));
      return isOpen && pendingQty > 0;
    });

    // Deduplicate by order_id
    const uniqueOrders = Array.from(
      new Map(activeOrders.map((o) => [o.order_id, o])).values()
    );

    return { orders: uniqueOrders, initialized: true };
  }),

  setTrades: (trades) => set({ trades }),

  upsertOrder: (raw) => set((state) => {
    const updated = normalizeOrder(raw);
    if (!updated.order_id) return state;

    // If the incoming socket event marks the order as closed/cancelled/rejected, 
    // immediately remove it from active orders instead of keeping it in state.
    if (!isOpenOrder(updated)) {
      return {
        orders: state.orders.filter((o) => o.order_id !== updated.order_id),
      };
    }

    const index = state.orders.findIndex((o) => o.order_id === updated.order_id);
    if (index >= 0) {
      const copy = [...state.orders];
      copy[index] = {
        ...copy[index],
        ...updated,
      };
      return { orders: copy };
    }

    // New open order
    return { orders: [updated, ...state.orders] };
  }),

  addTrade: (raw) => set((state) => {
    const updated = normalizeTrade(raw);
    if (!updated.trade_id) return state;
    if (state.trades.some((t) => t.trade_id === updated.trade_id)) return state;
    return { trades: [updated, ...state.trades] };
  }),

  reset: () => set({ orders: [], trades: [], initialized: false }),
}));