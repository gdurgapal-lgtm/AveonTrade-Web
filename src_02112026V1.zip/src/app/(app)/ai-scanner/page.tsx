"use client";

import { useState, useEffect, useMemo, useRef } from "react";
import {
  PREDEFINED_WATCHLIST_GROUPS,
  PredefinedWatchlistGroup,
} from "@/data/predefinedWatchlists";
import { resolvePredefinedWatchlist } from "@/lib/watchlistLoader";
import { useMarketStream } from "@/hooks/useMarketStream";
import {
  feedToken,
  isIndexInstrument,
  exchangeSegmentFor,
  normalizeInstrument,
  type Instrument,
  type TransactionType,
  type ProductType,
  type OrderKind,
} from "@/types/trading";
import {
  ScannedSignal,
  ScannerCategory,
  ScannerTimeframe,
} from "@/types/aiScanner";
import {
  evaluateInstrumentSignal,
  getScannerCandleFreshness,
  type ScannerCandle,
} from "@/lib/aiScannerEngine";
import OrderTicketModal from "@/components/market/OrderTicketModal";
import MarketDepth from "@/components/market/MarketDepth";
import dynamic from "next/dynamic";
import {
  Loader2,
  ArrowUpDown,
  Activity,
  BarChart3,
  Layers,
  Sparkles,
  AlertTriangle,
  X,
} from "lucide-react";

const ChartViewPanel = dynamic(
  () => import("@/components/market/ChartViewPanel"),
  {
    ssr: false,
    loading: () => (
      <div className="flex h-full w-full items-center justify-center bg-aveon-panel text-xs text-aveon-muted font-mono">
        Loading Chart Workspace...
      </div>
    ),
  }
);

const TIMEFRAMES: ScannerTimeframe[] = ["5m", "15m", "1h", "1D"];
const CHART_RANGES = [
  { label: "1D", days: 1 },
  { label: "1W", days: 7 },
  { label: "1M", days: 30 },
  { label: "6M", days: 180 },
  { label: "1Y", days: 365 },
];
const CHART_TIMEFRAMES = ["1m", "5m", "15m", "1h", "D"];

const CATEGORIES: { id: ScannerCategory; label: string }[] = [
  { id: "ALL", label: "All Signals" },
  { id: "BULLISH_BREAKOUT", label: "Bullish Breakouts" },
  { id: "BEARISH_BREAKDOWN", label: "Bearish Breakdowns" },
  { id: "VOLUME_SPIKE", label: "Volume Spikes" },
  { id: "EMA_CROSSOVER", label: "EMA Crossovers" },
  { id: "RSI_REVERSAL", label: "RSI Reversals" },
];

type SortKey =
  | "symbol"
  | "ltp"
  | "change"
  | "rsi"
  | "confidence"
  | "rr"
  | "volume";

interface EnrichedSignal extends ScannedSignal {
  sector: string;
  dataStatus: string;
}

interface LiveTechnicalReport {
  symbol: string;
  exchange: string;
  timeframe: ScannerTimeframe;
  candleCount: number;
  lastCandleTime: string;
  quoteAgeMs: number;
  ltp: number;
  ema20: number;
  ema50: number;
  ema200: number | null;
  rsi14: number;
  atr14: number;
  support20: number;
  resistance20: number;
  latestVolume: number;
  avgVolume20: number;
  volumeRatio: number;
  shortTermBias: "BULLISH" | "BEARISH" | "NEUTRAL";
  positionalBias:
    | "BULLISH"
    | "BEARISH"
    | "NEUTRAL"
    | "INSUFFICIENT_200_BARS";
  signal: EnrichedSignal;
}

function computeEMA(values: number[], period: number): number | null {
  if (values.length < period || period <= 0) return null;
  const k = 2 / (period + 1);
  let ema =
    values.slice(0, period).reduce((sum, v) => sum + v, 0) / period;
  for (let i = period; i < values.length; i++) {
    ema = values[i] * k + ema * (1 - k);
  }
  return ema;
}

function computeATR14(candles: ScannerCandle[]): number {
  if (candles.length < 15) return 0;
  const trs: number[] = [];
  for (let i = 1; i < candles.length; i++) {
    const cur = candles[i];
    const prevClose = candles[i - 1].C;
    const tr = Math.max(
      cur.H - cur.L,
      Math.abs(cur.H - prevClose),
      Math.abs(cur.L - prevClose)
    );
    trs.push(tr);
  }
  const recent = trs.slice(-14);
  return recent.reduce((sum, v) => sum + v, 0) / recent.length;
}

function buildVerifiedTechnicalReport(
  sig: EnrichedSignal,
  candles: ScannerCandle[],
  quoteReceivedAt: number,
  liveLtp: number,
  timeframe: ScannerTimeframe
): LiveTechnicalReport | null {
  if (
    !candles ||
    candles.length < 55 ||
    !Number.isFinite(liveLtp) ||
    liveLtp <= 0
  ) {
    return null;
  }
  const closes = candles.map((c) => c.C);
  const ema20 = computeEMA(closes, 20);
  const ema50 = computeEMA(closes, 50);
  const ema200 = closes.length >= 200 ? computeEMA(closes, 200) : null;
  if (ema20 === null || ema50 === null) return null;

  const recent20 = candles.slice(-20);
  const support20 = Math.min(...recent20.map((c) => c.L));
  const resistance20 = Math.max(...recent20.map((c) => c.H));
  const latestVolume = candles[candles.length - 1].V;
  const avgVolume20 =
    recent20.reduce((sum, c) => sum + c.V, 0) / recent20.length;
  const volumeRatio = avgVolume20 > 0 ? latestVolume / avgVolume20 : 0;
  const atr14 = computeATR14(candles);

  const shortTermBias: "BULLISH" | "BEARISH" | "NEUTRAL" =
    liveLtp > ema20 && ema20 > ema50 && sig.features.rsi14 >= 52
      ? "BULLISH"
      : liveLtp < ema20 && ema20 < ema50 && sig.features.rsi14 <= 48
      ? "BEARISH"
      : "NEUTRAL";

  const positionalBias:
    | "BULLISH"
    | "BEARISH"
    | "NEUTRAL"
    | "INSUFFICIENT_200_BARS" =
    ema200 === null
      ? "INSUFFICIENT_200_BARS"
      : liveLtp > ema50 && ema50 > ema200
      ? "BULLISH"
      : liveLtp < ema50 && ema50 < ema200
      ? "BEARISH"
      : "NEUTRAL";

  const instAny = sig.instrument as Instrument & {
    name?: string;
    instrumentSymbol?: string;
    tradingSymbol?: string;
    symbol?: string;
  };
  const displaySymbol =
    instAny.tradingSymbol ||
    instAny.symbol ||
    instAny.instrumentSymbol ||
    instAny.name;

  return {
    symbol: displaySymbol || sig.instrument.symbol,
    exchange:
      exchangeSegmentFor(sig.instrument) ||
      sig.instrument.exchange ||
      "NSE_EQ",
    timeframe,
    candleCount: candles.length,
    lastCandleTime: candles[candles.length - 1].DT,
    quoteAgeMs: Math.max(0, Date.now() - quoteReceivedAt),
    ltp: liveLtp,
    ema20,
    ema50,
    ema200,
    rsi14: sig.features.rsi14,
    atr14,
    support20,
    resistance20,
    latestVolume,
    avgVolume20,
    volumeRatio,
    shortTermBias,
    positionalBias,
    signal: sig,
  };
}

export default function AiScannerPage() {
  const [watchlists] = useState<PredefinedWatchlistGroup[]>(
    PREDEFINED_WATCHLIST_GROUPS
  );
  const [activeId, setActiveId] = useState<string>("nifty50");
  const [resolvedItemsMap, setResolvedItemsMap] = useState<
    Record<string, Instrument[]>
  >({});
  const [resolving, setResolving] = useState(true);

  const [timeframe, setTimeframe] = useState<ScannerTimeframe>("15m");
  const [selectedCategory, setSelectedCategory] =
    useState<ScannerCategory>("ALL");
  const [sideFilter, setSideFilter] = useState<"ALL" | "BUY" | "SELL">("ALL");
  const [minConfidence] = useState<number>(50);
  const [riskPerTrade, setRiskPerTrade] = useState<number>(2500);
  const [scannerCandles, setScannerCandles] = useState<
    Record<string, ScannerCandle[]>
  >({});
  const [scannerLoading, setScannerLoading] = useState(false);
  const [scannerDataErrors, setScannerDataErrors] = useState<
    Record<string, string>
  >({});
  const [searchQuery, setSearchQuery] = useState<string>("");

  const [sortKey, setSortKey] = useState<SortKey>("confidence");
  const [sortOrder, setSortOrder] = useState<"asc" | "desc">("desc");

  const [orderModalOpen, setOrderModalOpen] = useState(false);
  const [depthOrder, setDepthOrder] = useState<{
    side: TransactionType;
    price?: number;
    quantity?: number;
    productType?: ProductType;
    orderKind?: OrderKind;
  } | null>(null);
  const [activeOrderInstrument, setActiveOrderInstrument] =
    useState<Instrument | null>(null);
  const [cashPair, setCashPair] = useState<Instrument[]>([]);

  const [popupModalOpen, setPopupModalOpen] = useState(false);
  const [popupActiveTab, setPopupActiveTab] = useState<"CHART" | "DEPTH">(
    "CHART"
  );
  const [popupInstrument, setPopupInstrument] = useState<Instrument | null>(
    null
  );

  const [analyzedInstrument, setAnalyzedInstrument] =
    useState<Instrument | null>(null);

  const [chartRangeIdx, setChartRangeIdx] = useState(2);
  const [chartTimeframe, setChartTimeframe] = useState("15m");
  const [candles, setCandles] = useState<any[]>([]);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartMessage, setChartMessage] = useState<string | null>(null);

  const rawHistoryCache = useRef<Record<string, ScannerCandle[]>>({});

  useEffect(() => {
    const handleGlobalHotkeys = (event: KeyboardEvent) => {
      if (event.key === "Escape") {
        if (orderModalOpen) {
          event.preventDefault();
          setOrderModalOpen(false);
          setDepthOrder(null);
          return;
        }
        if (analyzedInstrument) {
          event.preventDefault();
          setAnalyzedInstrument(null);
          return;
        }
        if (popupModalOpen) {
          event.preventDefault();
          setPopupModalOpen(false);
          return;
        }
      }
    };

    window.addEventListener("keydown", handleGlobalHotkeys);
    return () => window.removeEventListener("keydown", handleGlobalHotkeys);
  }, [popupModalOpen, orderModalOpen, analyzedInstrument]);

  useEffect(() => {
    const openOrderEvent = (event: Event) => {
      const detail = (
        event as CustomEvent<{
          instrument?: Instrument;
          side?: TransactionType;
          price?: number;
          quantity?: number;
          productType?: ProductType;
          orderKind?: OrderKind;
        }>
      ).detail;
      const targetInst = detail?.instrument ?? popupInstrument;
      if (!targetInst) return;

      if (isIndexInstrument(targetInst)) {
        window.alert("Indices Instruments are non-tradable");
        return;
      }

      setActiveOrderInstrument(targetInst);
      setDepthOrder(
        detail?.side
          ? {
              side: detail.side,
              price: detail.price,
              quantity: detail.quantity,
              productType: detail.productType,
              orderKind: detail.orderKind,
            }
          : { side: "BUY" }
      );
      setOrderModalOpen(true);
    };

    window.addEventListener("aveon:open-order-entry", openOrderEvent);
    return () =>
      window.removeEventListener("aveon:open-order-entry", openOrderEvent);
  }, [popupInstrument]);

  useEffect(() => {
    let cancelled = false;

    async function loadActiveWatchlistTokens() {
      setResolving(true);
      if (resolvedItemsMap[activeId]) {
        if (!cancelled) setResolving(false);
        return;
      }

      try {
        const items = await resolvePredefinedWatchlist(activeId);
        if (!cancelled) {
          setResolvedItemsMap((prev) => ({ ...prev, [activeId]: items }));
        }
      } catch (err) {
        console.error(
          `Failed to resolve predefined watchlist ${activeId}:`,
          err
        );
      } finally {
        if (!cancelled) setResolving(false);
      }
    }

    loadActiveWatchlistTokens();
    return () => {
      cancelled = true;
    };
  }, [activeId, resolvedItemsMap]);

  const currentInstruments = resolvedItemsMap[activeId] ?? [];
  const activeCashPair = orderModalOpen ? cashPair : [];
  const { quotes, quotesByToken, connected } = useMarketStream(
    currentInstruments,
    popupInstrument,
    activeCashPair
  );

  useEffect(() => {
    if (
      !orderModalOpen ||
      !activeOrderInstrument ||
      !activeOrderInstrument.token
    ) {
      setCashPair([]);
      return;
    }

    const segment = exchangeSegmentFor(activeOrderInstrument).toUpperCase();
    const isCash = segment === "NSE_EQ" || segment === "BSE_EQ";
    if (!isCash) {
      setCashPair([activeOrderInstrument]);
      return;
    }

    let cancelled = false;
    const symbolQuery = (
      activeOrderInstrument.symbol ||
      activeOrderInstrument.tradingSymbol ||
      ""
    ).trim();
    const oppositeSegment = segment === "NSE_EQ" ? "BSE_EQ" : "NSE_EQ";
    const expectedMktSegId = oppositeSegment === "NSE_EQ" ? 1 : 3;

    setCashPair([activeOrderInstrument]);

    const fetchCashPair = async () => {
      try {
        const lookupUrl =
          "/api/broker/scrip-lookup?q=" + encodeURIComponent(symbolQuery);
        const response = await fetch(lookupUrl, { credentials: "include" });
        const json = await response.json();
        const hits =
          json?.data?.result?.hits?.hits ?? json?.data?.hits?.hits ?? [];
        const hitsArray = Array.isArray(hits) ? hits : [hits];

        const targetSym = symbolQuery.toUpperCase();
        const matchedOppositeHit = hitsArray.find((h: any) => {
          const source = h?._source || h;
          if (!source) return false;
          const hitSegment = String(
            source.ExchangeSegment || ""
          ).toUpperCase();
          const hitMktSegId = Number(
            source.MktSegId ?? source.nMarketSegmentId ?? 0
          );
          const isOppositeExchange =
            hitSegment === oppositeSegment || hitMktSegId === expectedMktSegId;
          if (!isOppositeExchange) return false;

          if (activeOrderInstrument.isin && source.sISINCode) {
            return (
              String(source.sISINCode).trim().toUpperCase() ===
              activeOrderInstrument.isin.trim().toUpperCase()
            );
          }
          const hitSym = String(source.sSymbolnew || source.sSymbol || "")
            .trim()
            .toUpperCase();
          return hitSym === targetSym;
        });

        if (cancelled) return;

        if (matchedOppositeHit) {
          const rawSource = (matchedOppositeHit._source ||
            matchedOppositeHit) as Record<string, unknown>;
          const oppositeInst = normalizeInstrument(rawSource);
          setCashPair([activeOrderInstrument, oppositeInst]);
        } else {
          setCashPair([activeOrderInstrument]);
        }
      } catch {
        if (!cancelled) setCashPair([activeOrderInstrument]);
      }
    };

    void fetchCashPair();

    return () => {
      cancelled = true;
    };
  }, [orderModalOpen, activeOrderInstrument]);

  useEffect(() => {
    if (!currentInstruments.length || resolving) return;
    let cancelled = false;
    setScannerLoading(true);
    setScannerCandles({});
    setScannerDataErrors({});
    const results: Record<string, ScannerCandle[]> = {};
    const errors: Record<string, string> = {};
    let cursor = 0;
    const interval = timeframe === "1D" ? "DAY" : "MIN";
    const days = timeframe === "1D" ? 365 : 15;
    const workerCount = Math.min(3, currentInstruments.length);

    const workers = Array.from({ length: workerCount }, async () => {
      while (!cancelled) {
        const index = cursor++;
        if (index >= currentInstruments.length) return;
        const inst = currentInstruments[index];
        const key = feedToken(inst) || `${inst.exchange}_${inst.token}`;
        const cacheKey = `${key}_${timeframe === "1D" ? "DAY" : "MIN"}`;

        try {
          if (rawHistoryCache.current[cacheKey]) {
            results[key] = rawHistoryCache.current[cacheKey];
            continue;
          }

          const segment =
            exchangeSegmentFor(inst) || inst.exchangeSegment || inst.exchange;
          if (!segment || !inst.token) {
            throw new Error("Instrument exchange segment/token missing");
          }
          const params = new URLSearchParams({
            exchangeSegment: String(segment),
            token: String(inst.token),
            interval,
            days: String(days),
            countBack: "3000",
          });
          const url = `/api/broker/chart-history?${params.toString()}`;
          const response = await fetch(url, {
            credentials: "include",
            cache: "no-store",
          });
          const payload = await response.json();
          if (
            !response.ok ||
            payload?.status === "error" ||
            !Array.isArray(payload?.data)
          ) {
            throw new Error(
              payload?.message ||
                `History request failed (${response.status})`
            );
          }
          const valid = payload.data
            .map((c: any) => ({
              O: Number(c.O ?? c.open),
              H: Number(c.H ?? c.high),
              L: Number(c.L ?? c.low),
              C: Number(c.C ?? c.close),
              V: Number(c.V ?? c.volume),
              DT: String(
                c.DT ??
                  c.datetime ??
                  (Number.isFinite(Number(c.time))
                    ? new Date(Number(c.time) * 1000).toISOString()
                    : "")
              ),
            }))
            .filter(
              (c: ScannerCandle) =>
                [c.O, c.H, c.L, c.C, c.V].every(Number.isFinite) && !!c.DT
            );
          if (valid.length < 55) {
            throw new Error(
              `Insufficient candle history (${valid.length}/55)`
            );
          }
          rawHistoryCache.current[cacheKey] = valid;
          results[key] = valid;
        } catch (error) {
          errors[key] =
            error instanceof Error
              ? error.message
              : "Historical data unavailable";
        }
      }
    });

    Promise.all(workers).then(() => {
      if (!cancelled) {
        setScannerCandles(results);
        setScannerDataErrors(errors);
        setScannerLoading(false);
      }
    });

    return () => {
      cancelled = true;
    };
  }, [currentInstruments, timeframe, resolving]);

  useEffect(() => {
    if (
      !popupModalOpen ||
      popupActiveTab !== "CHART" ||
      !popupInstrument ||
      !popupInstrument.token
    ) {
      setCandles([]);
      return;
    }

    let cancelled = false;
    setChartLoading(true);
    setChartMessage(null);

    const loadChartCandles = async () => {
      const segment =
        exchangeSegmentFor(popupInstrument) ||
        popupInstrument.exchange ||
        "NSE_EQ";
      const token = popupInstrument.token;
      const range = CHART_RANGES[chartRangeIdx] ?? CHART_RANGES[2];

      try {
        const params = new URLSearchParams({
          exchangeSegment: String(segment),
          token: String(token),
          interval: "MIN",
          days: String(range.days),
          countBack: "1500",
        });
        const proxyUrl = `/api/broker/chart-history?${params.toString()}`;

        const res = await fetch(proxyUrl, { credentials: "include" });
        const json = await res.json();

        if (cancelled) return;

        if (json && Array.isArray(json.data) && json.data.length > 0) {
          setCandles(json.data);
          setChartMessage(null);
        } else {
          setCandles([]);
          setChartMessage("No history records found for this instrument.");
        }
      } catch (err) {
        if (!cancelled) {
          console.error("Chart history fetch error:", err);
          setChartMessage("Broker chart data gateway connection offline.");
        }
      } finally {
        if (!cancelled) setChartLoading(false);
      }
    };

    void loadChartCandles();

    return () => {
      cancelled = true;
    };
  }, [popupModalOpen, popupActiveTab, popupInstrument, chartRangeIdx]);

  const scannedResults = useMemo(() => {
    if (resolving || scannerLoading || connected !== true) return [];
    const rawList = currentInstruments
      .map((inst) => {
        const key = feedToken(inst) || `${inst.exchange}_${inst.token}`;
        const quote = quotesByToken[key];
        if (
          !quote ||
          !quote.ltp ||
          quote.ltp <= 0 ||
          !quote.receivedAt ||
          Date.now() - quote.receivedAt > 30_000
        ) {
          return null;
        }
        const history = scannerCandles[key];
        if (!history) return null;
        const freshness = getScannerCandleFreshness(history, timeframe);
        if (!freshness.fresh) return null;
        const signal = evaluateInstrumentSignal(
          inst,
          history,
          timeframe,
          riskPerTrade,
          quote.ltp
        );
        if (!signal) return null;
        const sector =
          (inst as Instrument & { sector?: string }).sector || "—";
        return { ...signal, sector } as EnrichedSignal;
      })
      .filter((sig): sig is EnrichedSignal => sig !== null)
      .filter((sig) => {
        if (selectedCategory !== "ALL" && sig.category !== selectedCategory) {
          return false;
        }
        if (sideFilter !== "ALL" && sig.tradePlan.side !== sideFilter) {
          return false;
        }
        if (sig.confidence < minConfidence) return false;
        const instAny = sig.instrument as Instrument & {
          name?: string;
          instrumentSymbol?: string;
          tradingSymbol?: string;
          symbol?: string;
        };
        const symbol =
          instAny.tradingSymbol ||
          instAny.symbol ||
          instAny.instrumentSymbol ||
          instAny.name ||
          "";
        return (
          !searchQuery.trim() ||
          symbol.toLowerCase().includes(searchQuery.toLowerCase()) ||
          sig.sector.toLowerCase().includes(searchQuery.toLowerCase())
        );
      });

    return rawList.sort((a, b) => {
      const aInst = a.instrument as Instrument & {
        name?: string;
        instrumentSymbol?: string;
        tradingSymbol?: string;
        symbol?: string;
      };
      const bInst = b.instrument as Instrument & {
        name?: string;
        instrumentSymbol?: string;
        tradingSymbol?: string;
        symbol?: string;
      };
      const symbolA =
        aInst.tradingSymbol ||
        aInst.symbol ||
        aInst.instrumentSymbol ||
        aInst.name ||
        "";
      const symbolB =
        bInst.tradingSymbol ||
        bInst.symbol ||
        bInst.instrumentSymbol ||
        bInst.name ||
        "";

      const values: Record<SortKey, [number | string, number | string]> = {
        symbol: [symbolA, symbolB],
        ltp: [a.ltp, b.ltp],
        change: [a.features.priceChangePct, b.features.priceChangePct],
        rsi: [a.features.rsi14, b.features.rsi14],
        confidence: [a.confidence, b.confidence],
        rr: [a.tradePlan.riskRewardRatio, b.tradePlan.riskRewardRatio],
        volume: [a.features.volumeRatio, b.features.volumeRatio],
      };
      const [av, bv] = values[sortKey];
      const result =
        typeof av === "string"
          ? av.localeCompare(String(bv))
          : Number(av) - Number(bv);
      return sortOrder === "asc" ? result : -result;
    });
  }, [
    currentInstruments,
    quotesByToken,
    scannerCandles,
    scannerLoading,
    connected,
    timeframe,
    riskPerTrade,
    selectedCategory,
    sideFilter,
    minConfidence,
    searchQuery,
    resolving,
    sortKey,
    sortOrder,
  ]);

  const liveTechnicalReport = useMemo<{
    report: LiveTechnicalReport | null;
    blockReason: string | null;
  }>(() => {
    if (!analyzedInstrument) return { report: null, blockReason: null };
    if (connected !== true) {
      return {
        report: null,
        blockReason:
          "Live market stream disconnected. Analysis and order execution are halted.",
      };
    }
    const key =
      feedToken(analyzedInstrument) ||
      `${analyzedInstrument.exchange}_${analyzedInstrument.token}`;
    const quote = quotesByToken[key];
    if (!quote || !quote.ltp || quote.ltp <= 0 || !quote.receivedAt) {
      return {
        report: null,
        blockReason: "No live exchange tick received for this instrument.",
      };
    }
    const quoteAge = Date.now() - quote.receivedAt;
    if (quoteAge > 30_000) {
      const ageSec = Math.round(quoteAge / 1000);
      return {
        report: null,
        blockReason: `Live quote is stale (${ageSec}s old > 30s limit). Waiting for fresh exchange tick.`,
      };
    }
    const history = scannerCandles[key];
    if (!history || history.length < 55) {
      return {
        report: null,
        blockReason:
          scannerDataErrors[key] ||
          "Insufficient authenticated historical candles (< 55 bars).",
      };
    }
    const freshness = getScannerCandleFreshness(history, timeframe);
    if (!freshness.fresh) {
      return {
        report: null,
        blockReason:
          "Historical candle series is stale for the selected timeframe. Execution is blocked.",
      };
    }
    const signal = evaluateInstrumentSignal(
      analyzedInstrument,
      history,
      timeframe,
      riskPerTrade,
      quote.ltp
    );
    if (!signal) {
      return {
        report: null,
        blockReason:
          "No actionable technical signal meets validation thresholds on current live data.",
      };
    }
    const sector =
      (analyzedInstrument as Instrument & { sector?: string }).sector || "—";
    const enriched: EnrichedSignal = {
      ...signal,
      sector,
      dataStatus: "VERIFIED_LIVE",
    };
    const report = buildVerifiedTechnicalReport(
      enriched,
      history,
      quote.receivedAt,
      quote.ltp,
      timeframe
    );
    if (!report) {
      return {
        report: null,
        blockReason:
          "Unable to compute verified technical indicators from current candle history.",
      };
    }
    return { report, blockReason: null };
  }, [
    analyzedInstrument,
    connected,
    quotesByToken,
    scannerCandles,
    scannerDataErrors,
    timeframe,
    riskPerTrade,
  ]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) {
      setSortOrder(sortOrder === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortOrder("desc");
    }
  };

  const handleOpenPopup = (inst: Instrument, tab: "CHART" | "DEPTH") => {
    setPopupInstrument(inst);
    setPopupActiveTab(tab);
    setPopupModalOpen(true);
  };

  const popupInstAny = popupInstrument as Instrument & {
    companyName?: string;
    name?: string;
    instrumentSymbol?: string;
    tradingSymbol?: string;
    symbol?: string;
  };
  const popupDisplaySymbol =
    popupInstAny?.tradingSymbol ||
    popupInstAny?.symbol ||
    popupInstAny?.instrumentSymbol ||
    popupInstAny?.name;

  const activeQuote = popupInstrument
    ? quotesByToken[feedToken(popupInstrument) ?? ""] ||
      quotes[popupDisplaySymbol ?? ""] ||
      quotes[popupInstrument.tradingSymbol ?? ""] ||
      quotes[popupInstrument.symbol]
    : undefined;

  return (
    <div className="flex h-full w-full flex-col gap-2 overflow-hidden p-1 text-sm font-mono text-aveon-text bg-aveon-bg">
      {/* Top Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 rounded border border-aveon-border bg-aveon-panel px-3 py-2 shadow-sm flex-shrink-0">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-sm font-bold text-aveon-text tracking-wide">
              Live AI Market Scanner & Screener
            </h1>
            <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-blue-500/15 text-blue-500 border border-blue-500/30">
              INSTITUTIONAL FEED
            </span>
          </div>
          <p className="mt-0.5 text-[11px] text-aveon-muted font-sans">
            Live broker quotes and historical-candle-based technical screening
            with ATR-based trade levels.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded border border-aveon-border bg-aveon-panel2 px-2.5 py-1 text-xs">
            <Activity
              size={13}
              className={
                connected
                  ? "text-emerald-500 animate-pulse"
                  : "text-amber-500"
              }
            />
            <span
              className={
                connected
                  ? "text-emerald-500 font-bold"
                  : "text-amber-500 font-bold"
              }
            >
              {connected ? "STREAM ACTIVE" : "CONNECTING..."}
            </span>
          </div>
        </div>
      </div>

      {/* Predefined Watchlist Group Tabs & Filters */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 rounded border border-aveon-border bg-aveon-panel p-2 text-xs shadow-sm flex-shrink-0">
        <div className="flex flex-wrap items-center gap-2.5">
          <div className="flex flex-wrap items-center gap-1 rounded border border-aveon-border bg-aveon-panel2 p-0.5">
            {watchlists.map((group) => (
              <button
                key={group.id}
                onClick={() => setActiveId(group.id)}
                className={`rounded px-2.5 py-1 font-semibold transition ${
                  activeId === group.id
                    ? "bg-aveon-primary text-white"
                    : "text-aveon-muted hover:text-aveon-text"
                }`}
              >
                {group.name}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 rounded border border-aveon-border bg-aveon-panel2 p-0.5">
            {TIMEFRAMES.map((tf) => (
              <button
                key={tf}
                onClick={() => setTimeframe(tf)}
                className={`rounded px-2 py-1 font-semibold transition ${
                  timeframe === tf
                    ? "bg-aveon-primary/20 text-aveon-primary"
                    : "text-aveon-muted hover:text-aveon-text"
                }`}
              >
                {tf}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-1 rounded border border-aveon-border bg-aveon-panel2 p-0.5">
            {(["ALL", "BUY", "SELL"] as const).map((side) => (
              <button
                key={side}
                onClick={() => setSideFilter(side)}
                className={`rounded px-2.5 py-1 font-semibold transition ${
                  sideFilter === side
                    ? side === "BUY"
                      ? "bg-emerald-600 text-white"
                      : side === "SELL"
                      ? "bg-rose-600 text-white"
                      : "bg-aveon-primary/20 text-aveon-primary"
                    : "text-aveon-muted hover:text-aveon-text"
                }`}
              >
                {side}
              </button>
            ))}
          </div>

          <input
            type="text"
            placeholder="Search symbol or sector..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="rounded border border-aveon-border bg-aveon-panel2 px-2.5 py-1 text-xs text-aveon-text placeholder-aveon-muted focus:border-blue-500 focus:outline-none w-48 font-mono"
          />
        </div>

        <div className="flex items-center gap-2">
          <span className="text-aveon-muted">Risk/Trade (₹):</span>
          <input
            type="number"
            value={riskPerTrade}
            onChange={(e) =>
              setRiskPerTrade(Math.max(500, Number(e.target.value) || 1000))
            }
            className="w-20 rounded border border-aveon-border bg-aveon-panel2 px-2 py-1 text-right text-aveon-text font-mono text-xs"
          />
        </div>
      </div>

      {/* Category Pills */}
      <div className="flex flex-wrap items-center gap-1.5 flex-shrink-0">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setSelectedCategory(cat.id)}
            className={`rounded border px-2.5 py-1 text-xs font-semibold transition ${
              selectedCategory === cat.id
                ? "border-blue-500 bg-blue-500/20 text-blue-500"
                : "border-aveon-border bg-aveon-panel text-aveon-muted hover:text-aveon-text"
            }`}
          >
            {cat.label}
          </button>
        ))}
      </div>

      {/* Tabular List View */}
      {connected !== true && !resolving ? (
        <div className="rounded border border-amber-500/40 bg-amber-500/10 p-3 text-xs text-amber-300">
          Market feed is not confirmed live. Scanner signals and order actions
          are disabled until the feed reconnects.
        </div>
      ) : scannerLoading ? (
        <div className="rounded border border-aveon-border bg-aveon-panel p-6 text-center text-xs text-aveon-muted">
          Loading authenticated historical candles for the selected universe…
        </div>
      ) : resolving ? (
        <div className="flex flex-col items-center justify-center p-12 bg-aveon-panel rounded border border-aveon-border shadow-sm flex-1">
          <Loader2 size={28} className="animate-spin text-blue-500 mb-2" />
          <p className="text-xs text-aveon-text font-semibold">
            Resolving Scrip Master Exchange Tokens for{" "}
            {watchlists.find((w) => w.id === activeId)?.name}...
          </p>
        </div>
      ) : scannedResults.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-10 bg-aveon-panel rounded border border-aveon-border text-center shadow-sm flex-1">
          <p className="text-xs font-bold text-aveon-text">
            No signals match your filter criteria.
          </p>
          <p className="text-[11px] text-aveon-muted mt-1 font-sans">
            No validated setup is available. Signals are withheld when live
            quotes or historical candles are missing or stale.
          </p>
          {Object.keys(scannerDataErrors).length > 0 && (
            <p className="text-[10px] text-amber-400 mt-2">
              Historical data unavailable for{" "}
              {Object.keys(scannerDataErrors).length} instrument(s). No
              substitute values are generated.
            </p>
          )}
        </div>
      ) : (
        <div className="rounded border border-aveon-border bg-aveon-panel overflow-hidden shadow-sm flex-1 flex flex-col min-h-0">
          <div className="overflow-x-auto overflow-y-auto scrollbar-thin flex-1 w-full">
            <table className="w-full text-sm">
              <thead className="sticky top-0 z-20 border-b border-aveon-border bg-aveon-panel text-aveon-muted uppercase tracking-wider text-xs font-bold shadow-sm">
                <tr>
                  <th
                    className="px-3.5 py-2.5 text-left cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("symbol")}
                  >
                    Symbol / Sector{" "}
                    <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("ltp")}
                  >
                    LTP (₹) <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("change")}
                  >
                    Bar Change (%){" "}
                    <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th className="px-3.5 py-2.5 text-center">Setup Trigger</th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("rsi")}
                  >
                    RSI (14) <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("volume")}
                  >
                    Volume / Avg{" "}
                    <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("symbol")}
                  >
                    Instrument{" "}
                    <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("rr")}
                  >
                    R : R <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th
                    className="px-3.5 py-2.5 text-right cursor-pointer hover:text-aveon-text"
                    onClick={() => toggleSort("confidence")}
                  >
                    Setup Score{" "}
                    <ArrowUpDown size={11} className="inline ml-1" />
                  </th>
                  <th className="px-3.5 py-2.5 text-center">Quick Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-aveon-border/40 font-mono">
                {scannedResults.map((sig) => {
                  const isBuy = sig.tradePlan.side === "BUY";
                  const isPositive = sig.features.priceChangePct >= 0;
                  const instAny = sig.instrument as Instrument & {
                    name?: string;
                    instrumentSymbol?: string;
                    tradingSymbol?: string;
                    symbol?: string;
                  };
                  const displaySymbol =
                    instAny.tradingSymbol ||
                    instAny.symbol ||
                    instAny.instrumentSymbol ||
                    instAny.name ||
                    sig.instrument.symbol;

                  return (
                    <tr
                      key={sig.id}
                      className="transition-colors hover:bg-aveon-panel2/60"
                    >
                      <td className="px-3.5 py-2">
                        <div className="flex items-center gap-1.5">
                          <span className="font-bold text-aveon-text text-sm tracking-wide">
                            {displaySymbol}
                          </span>
                          <span
                            className={`px-1 py-0.2 text-[9px] font-bold rounded uppercase ${
                              isBuy
                                ? "bg-emerald-500/20 text-emerald-500"
                                : "bg-rose-500/20 text-rose-500"
                            }`}
                          >
                            {sig.tradePlan.side}
                          </span>
                        </div>
                        <div className="text-[11px] text-aveon-muted font-sans truncate max-w-[150px]">
                          {sig.sector}
                        </div>
                      </td>

                      <td
                        className={`px-3.5 py-2 text-right font-bold text-sm ${
                          isPositive ? "text-emerald-500" : "text-rose-500"
                        }`}
                      >
                        ₹
                        {sig.ltp.toLocaleString("en-IN", {
                          minimumFractionDigits: 2,
                        })}
                      </td>

                      <td
                        className={`px-3.5 py-2 text-right font-bold text-sm ${
                          isPositive ? "text-emerald-500" : "text-rose-500"
                        }`}
                      >
                        {isPositive ? "+" : ""}
                        {sig.features.priceChangePct.toFixed(2)}%
                      </td>

                      <td className="px-3.5 py-2 text-center">
                        <span className="rounded bg-aveon-panel2 px-2 py-0.5 text-xs text-aveon-text border border-aveon-border font-sans">
                          {sig.categoryLabel}
                        </span>
                      </td>

                      <td className="px-3.5 py-2 text-right text-aveon-text font-bold">
                        {sig.features.rsi14.toFixed(2)}
                      </td>

                      <td className="px-3.5 py-2 text-right text-aveon-muted">
                        {sig.features.volumeRatio > 0
                          ? `${sig.features.volumeRatio.toFixed(2)}x`
                          : "N/A"}
                      </td>

                      <td className="px-3.5 py-2 text-right text-aveon-muted">
                        {sig.instrument.instrumentName ||
                          sig.instrument.exchangeSegment ||
                          sig.instrument.exchange}
                      </td>

                      <td className="px-3.5 py-2 text-right text-emerald-500 font-bold">
                        1:{Number(sig.tradePlan.riskRewardRatio).toFixed(2)}
                      </td>

                      <td className="px-3.5 py-2 text-right">
                        <span
                          className={`inline-flex items-center px-1.5 py-0.5 rounded text-xs font-bold ${
                            sig.confidence >= 80
                              ? "bg-emerald-500/15 text-emerald-500 border border-emerald-500/30"
                              : sig.confidence >= 65
                              ? "bg-blue-500/15 text-blue-500 border border-blue-500/30"
                              : "bg-amber-500/15 text-amber-500 border border-amber-500/30"
                          }`}
                        >
                          {sig.confidence}%
                        </span>
                      </td>

                      <td
                        className="px-3.5 py-2 text-center"
                        onClick={(e) => e.stopPropagation()}
                      >
                        <div className="flex items-center justify-center gap-1">
                          <button
                            disabled={sig.tradePlan.suggestedQty <= 0}
                            onClick={() => {
                              if (sig.tradePlan.suggestedQty <= 0) return;
                              if (isIndexInstrument(sig.instrument)) {
                                window.alert(
                                  "Indices Instruments are non-tradable"
                                );
                                return;
                              }
                              setActiveOrderInstrument(sig.instrument);
                              setDepthOrder({
                                side: sig.tradePlan.side,
                                price: sig.ltp,
                                quantity: sig.tradePlan.suggestedQty,
                              });
                              setOrderModalOpen(true);
                            }}
                            className={`h-5 w-5 rounded text-xs font-bold text-white transition flex items-center justify-center disabled:opacity-40 ${
                              isBuy
                                ? "bg-emerald-600 hover:bg-emerald-500"
                                : "bg-rose-600 hover:bg-rose-500"
                            }`}
                            title={`Place ${sig.tradePlan.side} Order`}
                          >
                            {sig.tradePlan.side === "BUY" ? "B" : "S"}
                          </button>
                          <button
                            onClick={() =>
                              setAnalyzedInstrument(sig.instrument)
                            }
                            className="px-2 py-0.5 rounded border border-sky-500/40 bg-sky-500/10 text-xs text-sky-400 hover:bg-sky-500/20 transition flex items-center gap-1 font-semibold"
                            title="Inspect Live Technical Breakdown & Trade Plan"
                          >
                            <Sparkles size={11} /> Analyze
                          </button>
                          <button
                            onClick={() =>
                              handleOpenPopup(sig.instrument, "CHART")
                            }
                            className="px-2 py-0.5 rounded border border-aveon-border bg-aveon-panel2 text-xs text-aveon-muted hover:text-aveon-text transition flex items-center gap-1"
                            title="Open Price Chart Modal"
                          >
                            <BarChart3 size={12} /> Chart
                          </button>
                          <button
                            onClick={() =>
                              handleOpenPopup(sig.instrument, "DEPTH")
                            }
                            className="px-2 py-0.5 rounded border border-aveon-border bg-aveon-panel2 text-xs text-aveon-muted hover:text-aveon-text transition flex items-center gap-1"
                            title="Open Market Depth Modal"
                          >
                            <Layers size={12} /> Depth
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Live Verified Technical Breakdown Modal */}
      {analyzedInstrument && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
          <div className="flex w-full max-w-2xl flex-col rounded border border-aveon-border bg-aveon-panel text-aveon-text shadow-2xl overflow-hidden font-mono">
            <div className="flex items-center justify-between border-b border-aveon-border bg-aveon-panel2 px-4 py-2.5">
              <div className="flex items-center gap-2">
                <Sparkles size={15} className="text-sky-400" />
                <span className="text-sm font-bold">
                  Live Technical Analysis — {popupDisplaySymbol}
                </span>
                <span className="rounded bg-aveon-panel px-1.5 py-0.5 text-[10px] text-aveon-muted border border-aveon-border">
                  {exchangeSegmentFor(analyzedInstrument)} • {timeframe}
                </span>
              </div>
              <button
                onClick={() => setAnalyzedInstrument(null)}
                className="rounded p-1 text-aveon-muted hover:text-aveon-text"
              >
                <X size={16} />
              </button>
            </div>

            <div className="p-4 space-y-3 text-xs">
              {liveTechnicalReport.blockReason ||
              !liveTechnicalReport.report ? (
                <div className="flex items-start gap-2.5 rounded border border-rose-500/40 bg-rose-500/10 p-3 text-rose-300">
                  <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                  <div>
                    <p className="font-bold">
                      Live Validation Gate Blocked Analysis
                    </p>
                    <p className="mt-1 text-[11px] font-sans">
                      {liveTechnicalReport.blockReason}
                    </p>
                  </div>
                </div>
              ) : (
                <>
                  <div className="flex flex-wrap items-center justify-between gap-2 rounded border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 text-[11px]">
                    <span className="text-emerald-400 font-bold">
                      VERIFIED LIVE FEED • Quote Age:{" "}
                      {(liveTechnicalReport.report.quoteAgeMs / 1000).toFixed(
                        1
                      )}
                      s
                    </span>
                    <span className="text-aveon-muted">
                      Last Candle: {liveTechnicalReport.report.lastCandleTime} (
                      {liveTechnicalReport.report.candleCount} bars)
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2.5">
                    <div className="rounded border border-aveon-border bg-aveon-panel2 p-2.5">
                      <p className="text-[10px] uppercase text-aveon-muted">
                        Short-Term Bias ({timeframe} EMA 20/50 + RSI)
                      </p>
                      <p
                        className={`mt-1 text-sm font-bold ${
                          liveTechnicalReport.report.shortTermBias === "BULLISH"
                            ? "text-emerald-400"
                            : liveTechnicalReport.report.shortTermBias ===
                              "BEARISH"
                            ? "text-rose-400"
                            : "text-amber-400"
                        }`}
                      >
                        {liveTechnicalReport.report.shortTermBias}
                      </p>
                    </div>
                    <div className="rounded border border-aveon-border bg-aveon-panel2 p-2.5">
                      <p className="text-[10px] uppercase text-aveon-muted">
                        Positional Trend (EMA 50/200)
                      </p>
                      <p
                        className={`mt-1 text-sm font-bold ${
                          liveTechnicalReport.report.positionalBias ===
                          "BULLISH"
                            ? "text-emerald-400"
                            : liveTechnicalReport.report.positionalBias ===
                              "BEARISH"
                            ? "text-rose-400"
                            : "text-aveon-muted"
                        }`}
                      >
                        {liveTechnicalReport.report.positionalBias ===
                        "INSUFFICIENT_200_BARS"
                          ? "Requires >= 200 Bars"
                          : liveTechnicalReport.report.positionalBias}
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 rounded border border-aveon-border bg-aveon-panel2 p-3">
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        Live LTP
                      </span>
                      <span className="font-bold text-aveon-text">
                        ₹{liveTechnicalReport.report.ltp.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        EMA 20 / EMA 50
                      </span>
                      <span className="font-bold text-aveon-text">
                        ₹{liveTechnicalReport.report.ema20.toFixed(2)} / ₹
                        {liveTechnicalReport.report.ema50.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        EMA 200
                      </span>
                      <span className="font-bold text-aveon-text">
                        {liveTechnicalReport.report.ema200 !== null
                          ? `₹${liveTechnicalReport.report.ema200.toFixed(2)}`
                          : "N/A (<200 bars)"}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        RSI (14) / ATR (14)
                      </span>
                      <span className="font-bold text-aveon-text">
                        {liveTechnicalReport.report.rsi14.toFixed(2)} / ₹
                        {liveTechnicalReport.report.atr14.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        20-Bar Support / Resistance
                      </span>
                      <span className="font-bold text-aveon-text">
                        ₹{liveTechnicalReport.report.support20.toFixed(2)} / ₹
                        {liveTechnicalReport.report.resistance20.toFixed(2)}
                      </span>
                    </div>
                    <div>
                      <span className="text-[10px] text-aveon-muted block">
                        Bar Vol vs 20-Bar Avg
                      </span>
                      <span className="font-bold text-aveon-text">
                        {liveTechnicalReport.report.volumeRatio.toFixed(2)}x (
                        {Math.round(
                          liveTechnicalReport.report.latestVolume
                        ).toLocaleString("en-IN")}
                        )
                      </span>
                    </div>
                  </div>

                  <div className="rounded border border-aveon-border bg-aveon-panel2 p-3">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-[11px] font-bold uppercase text-aveon-muted">
                        Validated{" "}
                        {liveTechnicalReport.report.signal.categoryLabel} Plan
                      </span>
                      <span className="text-xs font-bold text-sky-400">
                        Score: {liveTechnicalReport.report.signal.confidence}% •
                        R:R 1:
                        {Number(
                          liveTechnicalReport.report.signal.tradePlan
                            .riskRewardRatio
                        ).toFixed(2)}
                      </span>
                    </div>
                    <div className="grid grid-cols-4 gap-2 text-center">
                      <div className="rounded border border-aveon-border bg-aveon-panel p-2">
                        <span className="text-[10px] text-aveon-muted block">
                          Side
                        </span>
                        <span
                          className={`font-bold ${
                            liveTechnicalReport.report.signal.tradePlan.side ===
                            "BUY"
                              ? "text-emerald-400"
                              : "text-rose-400"
                          }`}
                        >
                          {liveTechnicalReport.report.signal.tradePlan.side}
                        </span>
                      </div>
                      <div className="rounded border border-aveon-border bg-aveon-panel p-2">
                        <span className="text-[10px] text-aveon-muted block">
                          Entry (Live LTP)
                        </span>
                        <span className="font-bold text-aveon-text">
                          ₹{liveTechnicalReport.report.ltp.toFixed(2)}
                        </span>
                      </div>
                      <div className="rounded border border-aveon-border bg-aveon-panel p-2">
                        <span className="text-[10px] text-aveon-muted block">
                          Stop Loss
                        </span>
                        <span className="font-bold text-rose-400">
                          ₹
                          {Number(
                            liveTechnicalReport.report.signal.tradePlan.stopLoss
                          ).toFixed(2)}
                        </span>
                      </div>
                      <div className="rounded border border-aveon-border bg-aveon-panel p-2">
                        <span className="text-[10px] text-aveon-muted block">
                          Target 1
                        </span>
                        <span className="font-bold text-emerald-400">
                          ₹
                          {Number(
                            liveTechnicalReport.report.signal.tradePlan.target1
                          ).toFixed(2)}
                        </span>
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center justify-end gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        const inst = analyzedInstrument;
                        setAnalyzedInstrument(null);
                        handleOpenPopup(inst, "CHART");
                      }}
                      className="rounded border border-aveon-border bg-aveon-panel2 px-3 py-1.5 text-xs font-semibold text-aveon-text hover:bg-aveon-panel"
                    >
                      Inspect Chart
                    </button>
                    <button
                      type="button"
                      disabled={
                        isIndexInstrument(analyzedInstrument) ||
                        liveTechnicalReport.report.signal.tradePlan
                          .suggestedQty <= 0
                      }
                      onClick={() => {
                        const rpt = liveTechnicalReport.report;
                        if (!rpt || rpt.signal.tradePlan.suggestedQty <= 0) {
                          return;
                        }
                        if (isIndexInstrument(analyzedInstrument)) {
                          window.alert(
                            "Indices Instruments are non-tradable"
                          );
                          return;
                        }
                        setActiveOrderInstrument(analyzedInstrument);
                        setDepthOrder({
                          side: rpt.signal.tradePlan.side,
                          price: rpt.ltp,
                          quantity: rpt.signal.tradePlan.suggestedQty,
                        });
                        setAnalyzedInstrument(null);
                        setOrderModalOpen(true);
                      }}
                      className={`rounded px-4 py-1.5 text-xs font-bold text-white transition disabled:opacity-40 ${
                        liveTechnicalReport.report.signal.tradePlan.side ===
                        "BUY"
                          ? "bg-emerald-600 hover:bg-emerald-500"
                          : "bg-rose-600 hover:bg-rose-500"
                      }`}
                    >
                      Open {liveTechnicalReport.report.signal.tradePlan.side}{" "}
                      Ticket (Qty:{" "}
                      {
                        liveTechnicalReport.report.signal.tradePlan
                          .suggestedQty
                      }
                      )
                    </button>
                  </div>
                </>
              )}
            </div>
          </div>
        </div>
      )}

      {/* Interactive Popup Modal */}
      {popupModalOpen && popupInstrument && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 p-4 backdrop-blur-sm">
          <div className="flex flex-col w-full max-w-6xl h-[680px] rounded border border-aveon-border bg-aveon-panel text-aveon-text shadow-2xl overflow-hidden font-mono">
            <div className="flex items-center justify-between border-b border-aveon-border px-4 py-2.5 bg-aveon-panel2">
              <div className="flex items-center gap-3">
                <span className="text-base font-bold text-aveon-text">
                  {popupDisplaySymbol}
                </span>
                <span className="text-xs text-aveon-muted">
                  {popupInstrument.exchange} •{" "}
                  {popupInstAny.companyName || popupDisplaySymbol}
                </span>
              </div>

              <div className="flex items-center gap-1 bg-aveon-panel p-0.5 rounded border border-aveon-border">
                <button
                  onClick={() => setPopupActiveTab("CHART")}
                  className={`px-3 py-1 rounded text-xs font-semibold transition ${
                    popupActiveTab === "CHART"
                      ? "bg-aveon-primary text-white"
                      : "text-aveon-muted hover:text-aveon-text"
                  }`}
                >
                  ChartViewPanel
                </button>
                <button
                  onClick={() => setPopupActiveTab("DEPTH")}
                  className={`px-3.5 py-1 rounded text-xs font-semibold transition ${
                    popupActiveTab === "DEPTH"
                      ? "bg-aveon-primary text-white"
                      : "text-aveon-muted hover:text-aveon-text"
                  }`}
                >
                  Market Depth
                </button>
              </div>

              <button
                onClick={() => setPopupModalOpen(false)}
                className="text-aveon-muted hover:text-aveon-text p-1 rounded transition"
              >
                <X size={16} />
              </button>
            </div>

            <div className="flex-1 overflow-hidden p-3 bg-aveon-bg flex min-h-0">
              {popupActiveTab === "CHART" ? (
                <div className="h-full w-full">
                  <ChartViewPanel
                    selected={popupInstrument}
                    quotes={quotes}
                    ranges={CHART_RANGES}
                    rangeIdx={chartRangeIdx}
                    setRangeIdx={setChartRangeIdx}
                    selectedQuote={activeQuote}
                    timeframes={CHART_TIMEFRAMES}
                    timeframe={chartTimeframe}
                    setTimeframe={setChartTimeframe}
                    candles={candles}
                    chartLoading={chartLoading}
                    chartMessage={chartMessage}
                  />
                </div>
              ) : (
                <div className="h-full w-full overflow-y-auto [&>div]:w-full [&>div]:max-w-none">
                  <MarketDepth
                    instrument={popupInstrument}
                    connected={Boolean(connected)}
                    quote={activeQuote}
                    onTrade={(request) => {
                      if (isIndexInstrument(popupInstrument)) {
                        window.alert("Indices Instruments are non-tradable");
                        return;
                      }
                      setActiveOrderInstrument(popupInstrument);
                      setDepthOrder(
                        request
                          ? {
                              side: request.side,
                              price: request.price,
                              quantity: request.quantity,
                              productType: request.productType,
                              orderKind: request.orderKind,
                            }
                          : null
                      );
                      setOrderModalOpen(true);
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* OrderTicketModal */}
      <OrderTicketModal
        open={orderModalOpen}
        instrument={activeOrderInstrument}
        cashOptions={activeCashPair}
        quotes={quotes}
        onClose={() => {
          setOrderModalOpen(false);
          setDepthOrder(null);
        }}
        initialSide={depthOrder?.side ?? "BUY"}
        initialProductType={depthOrder?.productType}
        initialQuantity={depthOrder?.quantity}
        initialPrice={depthOrder?.price}
        initialOrderKind={depthOrder?.orderKind}
      />
    </div>
  );
}