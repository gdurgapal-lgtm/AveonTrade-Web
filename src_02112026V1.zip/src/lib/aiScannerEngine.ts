import { Instrument, classifyInstrument } from "@/types/trading";
import { ScannedSignal, ScannerCategory, ScannerSignalType, ScannerTimeframe, TechnicalFeatures, TechnicalScore, TradePlan } from "@/types/aiScanner";

/** Candle values must come from the authenticated chart-history API. No quote-derived substitutes. */
export interface ScannerCandle { O: number; H: number; L: number; C: number; V: number; DT: string; }

function timestamp(value: string): number {
  const normalized = value.includes("T") ? value : value.replace(" ", "T");
  const zoned = /(?:Z|[+-]\d\d:\d\d)$/.test(normalized) ? normalized : `${normalized}+05:30`;
  const parsed = Date.parse(zoned);
  return Number.isFinite(parsed) ? parsed : 0;
}

function resample(candles: ScannerCandle[], timeframe: ScannerTimeframe): ScannerCandle[] {
  if (timeframe === "1D") return candles;
  const minutes = timeframe === "5m" ? 5 : timeframe === "15m" ? 15 : 60;
  const buckets = new Map<number, ScannerCandle>();
  for (const c of candles) {
    const ms = timestamp(c.DT);
    if (!ms || ![c.O,c.H,c.L,c.C,c.V].every(Number.isFinite) || c.C <= 0 || c.H < c.L) continue;
    const key = Math.floor(ms / (minutes * 60_000)) * minutes * 60_000;
    const current = buckets.get(key);
    if (!current) buckets.set(key, { ...c });
    else { current.H = Math.max(current.H, c.H); current.L = Math.min(current.L, c.L); current.C = c.C; current.V += c.V; }
  }
  return [...buckets.entries()].sort((a,b) => a[0]-b[0]).map(([ms,c]) => ({ ...c, DT: new Date(ms).toISOString() }));
}

function ema(values: number[], period: number): number[] {
  if (values.length < period) return [];
  const out: number[] = [];
  const alpha = 2 / (period + 1);
  let value = values.slice(0, period).reduce((a,b) => a+b, 0) / period;
  out.push(value);
  for (let i=period; i<values.length; i++) { value = values[i] * alpha + value * (1-alpha); out.push(value); }
  return out;
}

function computeFeatures(candlesInput: ScannerCandle[]): TechnicalFeatures | null {
  // CRITICAL FIX: Filter out legacy mock data older than 1 year to prevent historical pollution
  const oneYearAgo = Date.now() - 365 * 24 * 60 * 60_000;
  const recentCandles = candlesInput.filter(c => timestamp(c.DT) >= oneYearAgo);

  const candles = recentCandles.filter(c => [c.O,c.H,c.L,c.C,c.V].every(Number.isFinite) && c.C > 0 && c.H >= c.L);
  if (candles.length < 55) return null;
  const closes = candles.map(c => c.C);
  const e9 = ema(closes,9), e21 = ema(closes,21), e50 = ema(closes,50);
  if (!e9.length || !e21.length || !e50.length) return null;
  const last = candles[candles.length-1];
  const prev = candles[candles.length-2];
  const tr = candles.slice(1).map((c,i) => Math.max(c.H-c.L, Math.abs(c.H-candles[i].C), Math.abs(c.L-candles[i].C)));
  const atrWindow = tr.slice(-14);
  if (atrWindow.length < 14) return null;
  const atr14 = atrWindow.reduce((a,b)=>a+b,0)/14;
  const changes = closes.slice(-15).slice(1).map((v,i)=>v-closes.slice(-15)[i]);
  const gains = changes.map(v=>Math.max(v,0));
  const losses = changes.map(v=>Math.max(-v,0));
  const avgGain = gains.reduce((a,b)=>a+b,0)/14;
  const avgLoss = losses.reduce((a,b)=>a+b,0)/14;
  const rsi14 = avgLoss === 0 ? (avgGain === 0 ? 50 : 100) : 100 - 100/(1+avgGain/avgLoss);
  const prior = candles.slice(-21,-1);
  if (prior.length < 20) return null;
  const priorHigh = Math.max(...prior.map(c=>c.H));
  const priorLow = Math.min(...prior.map(c=>c.L));
  const avgVolume = prior.reduce((a,c)=>a+c.V,0)/prior.length;
  const volumeRatio = avgVolume > 0 ? last.V/avgVolume : 0;
  let vwap = 0;
  const latestMs = timestamp(last.DT);
  const sessionDate = new Date(latestMs).toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" });
  const sessionCandles = candles.filter(c => new Date(timestamp(c.DT)).toLocaleDateString("en-CA", { timeZone: "Asia/Kolkata" }) === sessionDate);
  if (sessionCandles.length) {
    const sessionVolume = sessionCandles.reduce((a,c)=>a+c.V,0);
    if (sessionVolume > 0) vwap = sessionCandles.reduce((a,c)=>a+((c.H+c.L+c.C)/3)*c.V,0)/sessionVolume;
  }
  const priceChangePct = prev.C > 0 ? ((last.C-prev.C)/prev.C)*100 : 0;
  const ema9 = e9[e9.length-1], ema21=e21[e21.length-1], ema50=e50[e50.length-1];
  const isBreakout = last.C > priorHigh;
  const isBreakdown = last.C < priorLow;
  const emaCross = ema9 > ema21 && prev.C <= ema21 ? "BULLISH" : ema9 < ema21 && prev.C >= ema21 ? "BEARISH" : "NONE";
  return { rsi14, ema9, ema21, ema50, vwap, atr14, volumeRatio, priceChangePct, isBreakout, isBreakdown, emaCross };
}

export function scoreTechnicalSetup(f: TechnicalFeatures): TechnicalScore {
  const factors: string[] = [];
  let trendScore = 0, momentumScore = 0, volumeScore = 0, volatilityScore = 0;
  const bullish = f.ema9 > f.ema21 && f.ema21 > f.ema50;
  const bearish = f.ema9 < f.ema21 && f.ema21 < f.ema50;
  if (bullish || bearish) { trendScore += 25; factors.push(bullish ? "EMA 9/21/50 bullish alignment" : "EMA 9/21/50 bearish alignment"); }
  if (f.emaCross !== "NONE") { trendScore += 10; factors.push(`${f.emaCross} EMA crossover`); }
  if (f.rsi14 >= 55 && f.rsi14 < 70) { momentumScore += 20; factors.push("Positive RSI momentum"); }
  else if (f.rsi14 <= 45 && f.rsi14 > 30) { momentumScore += 20; factors.push("Negative RSI momentum"); }
  if (f.volumeRatio >= 1.5) { volumeScore = 20; factors.push("Volume at least 1.5x previous 20-bar average"); }
  else if (f.volumeRatio >= 1.2) { volumeScore = 10; factors.push("Volume above previous 20-bar average"); }
  if (f.isBreakout || f.isBreakdown) { volatilityScore = 15; factors.push(f.isBreakout ? "Close above previous 20-bar high" : "Close below previous 20-bar low"); }
  return { totalScore: Math.min(100, trendScore+momentumScore+volumeScore+volatilityScore), trendScore, momentumScore, volumeScore, volatilityScore, confluenceFactors: factors };
}

export function buildTradePlan(ltp: number, f: TechnicalFeatures, side: "BUY"|"SELL", riskCapital: number, lotSize: number): TradePlan {
  const stopLoss = side === "BUY" ? ltp - f.atr14*1.5 : ltp + f.atr14*1.5;
  const unitRisk = Math.abs(ltp-stopLoss);
  const lot = Number.isFinite(lotSize) && lotSize > 0 ? Math.floor(lotSize) : 1;
  const affordableQty = unitRisk > 0 ? Math.floor(riskCapital/unitRisk) : 0;
  const suggestedQty = Math.floor(affordableQty/lot)*lot;
  const target1 = side === "BUY" ? ltp+unitRisk*2 : ltp-unitRisk*2;
  const target2 = side === "BUY" ? ltp+unitRisk*3 : ltp-unitRisk*3;
  return { side, entryZoneMin: ltp, entryZoneMax: ltp, stopLoss, target1, target2, riskRewardRatio: 2, suggestedQty, riskAmount: suggestedQty*unitRisk, invalidationReason: side === "BUY" ? `Close below ${stopLoss}` : `Close above ${stopLoss}` };
}

export function evaluateInstrumentSignal(instrument: Instrument, candlesInput: ScannerCandle[], timeframe: ScannerTimeframe, riskCapital: number, liveLtp: number): ScannedSignal | null {
  const candles = resample(candlesInput, timeframe);
  const f = computeFeatures(candles);
  if (!f || !Number.isFinite(liveLtp) || liveLtp <= 0) return null;

  // SAFETY GATE: Block evaluation if candle close deviates by more than 10% from live LTP
  const lastCandleClose = candles[candles.length - 1]?.C ?? 0;
  if (lastCandleClose > 0 && Math.abs(liveLtp - lastCandleClose) / lastCandleClose > 0.10) {
    return null;
  }

  const score = scoreTechnicalSetup(f);
  const vwapAvailable = timeframe === "1D" || f.vwap > 0;
  const bullish = vwapAvailable && f.ema9 > f.ema21 && f.ema21 > f.ema50 && (timeframe === "1D" || liveLtp > f.vwap) && f.rsi14 >= 50;
  const bearish = vwapAvailable && f.ema9 < f.ema21 && f.ema21 < f.ema50 && (timeframe === "1D" || liveLtp < f.vwap) && f.rsi14 <= 50;
  if ((!bullish && !bearish) || score.totalScore < 50) return null;
  const side = bullish ? "BUY" : "SELL";
  const category: ScannerCategory = f.isBreakout ? "BULLISH_BREAKOUT" : f.isBreakdown ? "BEARISH_BREAKDOWN" : f.volumeRatio >= 1.5 ? "VOLUME_SPIKE" : f.emaCross !== "NONE" ? "EMA_CROSSOVER" : "RSI_REVERSAL";
  const signalType: ScannerSignalType = score.totalScore >= 75 ? (bullish ? "STRONG_BUY" : "STRONG_SELL") : (bullish ? "BUY" : "SELL");
  const kind = classifyInstrument(instrument);
  const lotSize = kind === "FUT" || kind === "OPT" || kind === "COMM" || kind === "CUR"
    ? Number(instrument.regularLot)
    : 1;
  return { id: `${instrument.exchange}_${instrument.token}_${timeframe}`, instrument, ltp: liveLtp, timeframe, signalType, category, categoryLabel: category.replace(/_/g," "), confidence: score.totalScore, features: f, score, tradePlan: buildTradePlan(liveLtp,f,side,riskCapital,Number.isFinite(lotSize) ? lotSize : 0), scannedAt: Date.now() };
}

export function getScannerCandleFreshness(candles: ScannerCandle[], timeframe: ScannerTimeframe): { fresh: boolean; reason?: string } {
  if (!candles.length) return { fresh: false, reason: "No historical candles returned" };
  const last = timestamp(candles[candles.length - 1].DT);
  if (!last) return { fresh: false, reason: "Latest candle has an invalid timestamp" };

  const maxAge = timeframe === "1D" ? 30 * 24 * 60 * 60_000 : 7 * 24 * 60 * 60_000;
  if (Date.now() - last > maxAge || last > Date.now() + 2 * 60 * 60_000) {
    return { fresh: false, reason: "Historical candles are outside acceptable recent session window" };
  }
  return { fresh: true };
}