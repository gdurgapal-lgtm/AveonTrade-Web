import { Instrument } from "@/types/trading";

export type ScannerSignalType =
  | "STRONG_BUY"
  | "BUY"
  | "NEUTRAL"
  | "SELL"
  | "STRONG_SELL";

export type ScannerTimeframe = "5m" | "15m" | "1h" | "1D";

export type ScannerCategory =
  | "ALL"
  | "BULLISH_BREAKOUT"
  | "BEARISH_BREAKDOWN"
  | "VOLUME_SPIKE"
  | "EMA_CROSSOVER"
  | "RSI_REVERSAL";

export interface TechnicalFeatures {
  rsi14: number;
  ema9: number;
  ema21: number;
  ema50: number;
  vwap: number;
  atr14: number;
  volumeRatio: number; // Current volume vs 20-period average
  priceChangePct: number;
  isBreakout: boolean;
  isBreakdown: boolean;
  emaCross: "BULLISH" | "BEARISH" | "NONE";
}

export interface TechnicalScore {
  totalScore: number; // 0 to 100
  trendScore: number;
  momentumScore: number;
  volumeScore: number;
  volatilityScore: number;
  confluenceFactors: string[];
}

export interface TradePlan {
  side: "BUY" | "SELL";
  entryZoneMin: number;
  entryZoneMax: number;
  stopLoss: number;
  target1: number;
  target2: number;
  riskRewardRatio: number;
  suggestedQty: number;
  riskAmount: number;
  invalidationReason: string;
}

export interface ScannedSignal {
  id: string;
  instrument: Instrument;
  ltp: number;
  timeframe: ScannerTimeframe;
  signalType: ScannerSignalType;
  category: ScannerCategory;
  categoryLabel: string;
  confidence: number; // 0 to 100%
  features: TechnicalFeatures;
  score: TechnicalScore;
  tradePlan: TradePlan;
  scannedAt: number;
}