"use client";

import { create } from "zustand";
import { normalizeOrder, isOpenOrder, normalizeTrade, type OrderModel, type TradeModel, type RawOrderModel, type RawTradeModel } from "@/types/trading";

interface LiveOrderState {
  orders: OrderModel[];
  trades: TradeModel[];
  initialized: boolean;
  setOrders: (orders: OrderModel[]) => void;
  setTrades: (trades: TradeModel[]) => void;
  upsertOrder: (raw: RawOrderModel) => void;
  addTrade: (raw: RawTradeModel) => void;
  reconcileOrders: (rawOrders: RawOrderModel[], requestedAt: number) => void;
  reconcileTrades: (rawTrades: RawTradeModel[], requestedAt: number) => void;
  reset: () => void;
}

const orderEventAt = new Map<string, number>();

export const useLiveOrderStore = create<LiveOrderState>((set) => ({
  orders: [],
  trades: [],
  initialized: false,
  
  setOrders: (newOrders) => set((state) => {
    const normalized = newOrders.map(normalizeOrder);
    
    // Explicitly keep only orders that are verified open AND have valid pending quantities
    const activeOrders = normalized.filter((o) => {
      const isOpen = isOpenOrder(o);
      const pendingQty = o.pending_quantity ?? Math.max(0, o.quantity - (o.filled_quantity ?? 0));
      return isOpen && pendingQty > 0;
    });

    // Deduplicate by order_id
    const uniqueOrders = Array.from(
      new Map(activeOrders.map((o) => [o.order_id, o])).values()
    );

    return { orders: uniqueOrders, initialized: true };
  }),

  setTrades: (trades) => set({ trades }),

  upsertOrder: (raw) => set((state) => {
    const updated = normalizeOrder(raw);
    if (!updated.order_id) return state;
    orderEventAt.set(updated.order_id, Date.now());

    // If the incoming socket event marks the order as closed/cancelled/rejected, 
    // immediately remove it from active orders instead of keeping it in state.
    if (!isOpenOrder(updated)) {
      return {
        orders: state.orders.filter((o) => o.order_id !== updated.order_id),
      };
    }

    const index = state.orders.findIndex((o) => o.order_id === updated.order_id);
    if (index >= 0) {
      const copy = [...state.orders];
      copy[index] = {
        ...copy[index],
        ...updated,
      };
      return { orders: copy };
    }

    // New open order
    return { orders: [updated, ...state.orders] };
  }),

  addTrade: (raw) => set((state) => {
    const updated = normalizeTrade(raw);
    if (!updated.trade_id) return state;
    if (state.trades.some((t) => t.trade_id === updated.trade_id)) return state;
    return { trades: [updated, ...state.trades] };
  }),

  reconcileOrders: (rawOrders, requestedAt) => set((state) => {
    const snapshot = rawOrders.map(normalizeOrder).filter((order) => isOpenOrder(order));
    const snapshotById = new Map(snapshot.filter((o) => o.order_id).map((o) => [o.order_id, o]));
    // A WebSocket event received after this REST request began always wins,
    // including terminal events that removed an order from the active list.
    for (const [id, eventAt] of orderEventAt) {
      if (eventAt > requestedAt) snapshotById.delete(id);
    }
    const merged = new Map(snapshotById);
    for (const current of state.orders) {
      if (orderEventAt.get(current.order_id) && (orderEventAt.get(current.order_id) as number) > requestedAt) {
        merged.set(current.order_id, current);
      }
    }
    return { orders: Array.from(merged.values()), initialized: true };
  }),

  reconcileTrades: (rawTrades, requestedAt) => set((state) => {
    void requestedAt;
    const merged = new Map(state.trades.map((trade) => [trade.trade_id, trade]));
    for (const raw of rawTrades) {
      const trade = normalizeTrade(raw);
      if (trade.trade_id && !merged.has(trade.trade_id)) merged.set(trade.trade_id, trade);
    }
    return { trades: Array.from(merged.values()) };
  }),

  reset: () => {
    orderEventAt.clear();
    set({ orders: [], trades: [], initialized: false });
  },
}));