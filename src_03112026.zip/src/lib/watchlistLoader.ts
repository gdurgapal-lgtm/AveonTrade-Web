import { normalizeInstrument, type Instrument } from "@/types/trading";
import { PREDEFINED_WATCHLIST_GROUPS, WatchlistConstituent } from "@/data/predefinedWatchlists";

const WATCHLIST_TOKEN_CACHE = "aveontrade.predefined.watchlist.cache.v1";

export async function resolvePredefinedWatchlist(watchlistId: string): Promise<Instrument[]> {
  const group = PREDEFINED_WATCHLIST_GROUPS.find((g) => g.id === watchlistId);
  if (!group) return [];

  let cachedMap: Record<string, Instrument> = {};
  try {
    const raw = window.localStorage.getItem(WATCHLIST_TOKEN_CACHE);
    if (raw) cachedMap = JSON.parse(raw);
  } catch (e) {
    console.error("Cache load error", e);
  }

  const resolved: Instrument[] = [];
  const missing: WatchlistConstituent[] = [];

  group.items.forEach((item) => {
    if (cachedMap[item.symbol]) {
      resolved.push(cachedMap[item.symbol]);
    } else {
      missing.push(item);
    }
  });

  if (missing.length > 0) {
    await Promise.all(
      missing.map(async (item) => {
        try {
          const res = await fetch(`/api/broker/scrip-lookup?q=${encodeURIComponent(item.symbol)}`, { credentials: "include" });
          const json = await res.json();
          const hits = json?.data?.result?.hits?.hits ?? json?.data?.hits?.hits ?? json?.data?.result ?? json?.data ?? [];
          const rawHit = Array.isArray(hits) ? hits[0] : hits;
          const match = rawHit?._source || rawHit;
          if (match) {
            const inst = normalizeInstrument(match) as Instrument & { sector?: string; companyName?: string };
            inst.companyName = item.companyName;
            inst.sector = item.sector;
            if (!inst.symbol) inst.symbol = item.symbol;
            if (!inst.tradingSymbol) inst.tradingSymbol = item.symbol;
            cachedMap[item.symbol] = inst as Instrument;
            resolved.push(inst as Instrument);
          }
        } catch (err) {
          console.error(`Scrip lookup failed for predefined symbol ${item.symbol}:`, err);
        }
      })
    );

    try {
      window.localStorage.setItem(WATCHLIST_TOKEN_CACHE, JSON.stringify(cachedMap));
    } catch (e) {
      console.error("Cache save error", e);
    }
  }

  return resolved;
}