"use client";

import { useEffect } from "react";
import { useOrderStreamStore } from "@/lib/orderStreamStore";
import { useLiveOrderStore } from "@/lib/liveOrderStore";
import { fetchShared } from "@/lib/sharedFetch";
import { orderBookPath, tradeBookPath, positionsPath } from "@/lib/endpoints";
import { extractList, type RawOrderModel, type RawTradeModel } from "@/types/trading";

/** Keeps one authenticated order/trade stream alive for the whole app session. */
export default function TradingDataProvider() {
  useEffect(() => {
    let active = true;
    let wasLive = false;
    let hasConnectedOnce = false;
    let reconciling = false;
    const stream = useOrderStreamStore.getState();
    stream.acquire();

    const downloadPositions = async (reason: string) => {
      console.info(`[AveonTrade][TradingData DEBUG] Position API download started (${reason})`);
      const result = await fetchShared(positionsPath("daily", 1), reason === "reconnection");
      if (!active) return;
      console.info(`[AveonTrade][TradingData DEBUG] Position API download ${result.success ? "completed" : "failed"} (${reason})`, result.success ? { received: extractList(result.data, ["positions", "items", "records"]).length } : result.message);
    };

    const reconcileAfterReconnect = async () => {
      if (reconciling) return;
      reconciling = true;
      const requestedAt = Date.now();
      console.info("[AveonTrade][TradingData DEBUG] Reconciliation started after WebSocket connection/reconnection");
      try {
        const [ordersResult, tradesResult] = await Promise.all([
          fetchShared(orderBookPath(1, 100, -1), true),
          fetchShared(tradeBookPath(1, 100), true),
        ]);
        if (!active) return;
        if (ordersResult.success) {
          const rows = extractList<RawOrderModel>(ordersResult.data, ["orders", "orderBook", "order_book", "items", "records"]);
          useLiveOrderStore.getState().reconcileOrders(rows, requestedAt);
          console.info("[AveonTrade][TradingData DEBUG] Order reconciliation completed", { received: rows.length });
        } else console.warn("[AveonTrade][TradingData DEBUG] Order reconciliation failed", ordersResult.message);
        if (tradesResult.success) {
          const rows = extractList<RawTradeModel>(tradesResult.data, ["trades", "tradeBook", "trade_book", "items", "records"]);
          useLiveOrderStore.getState().reconcileTrades(rows, requestedAt);
          console.info("[AveonTrade][TradingData DEBUG] Trade reconciliation completed", { received: rows.length });
        } else console.warn("[AveonTrade][TradingData DEBUG] Trade reconciliation failed", tradesResult.message);
        await downloadPositions("reconnection");
      } catch (error) {
        console.error("[AveonTrade][TradingData DEBUG] Reconciliation error", error);
      } finally {
        reconciling = false;
      }
    };

    // Position is the only dataset downloaded via REST on initial login.
    void downloadPositions("login");
    const unsubscribe = useOrderStreamStore.subscribe((state) => {
      if (state.status === "live" && !wasLive) {
        if (hasConnectedOnce) void reconcileAfterReconnect();
        else console.info("[AveonTrade][TradingData DEBUG] WebSocket live; waiting for broker order/trade messages");
        wasLive = true;
        hasConnectedOnce = true;
      } else if (state.status !== "live" && wasLive) {
        wasLive = false;
        console.warn("[AveonTrade][TradingData DEBUG] WebSocket interrupted; automatic reconnection/reconciliation pending", { status: state.status });
      }
    });

    return () => {
      active = false;
      unsubscribe();
      useOrderStreamStore.getState().release();
    };
  }, []);

  return null;
}
