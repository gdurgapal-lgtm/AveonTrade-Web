"use client";

import { useEffect, useState } from "react";
import { Plus, X } from "lucide-react";
import { feedToken, normalizeInstrument, instrumentDisplayName, type Instrument } from "@/types/trading";
import { useMarketStream } from "@/hooks/useMarketStream";
import { formatNumber, pnlTone } from "@/lib/format";

const STORAGE_KEY = "aveon_market_watch_indices_v1";
const DEFAULT_NAMES = ["NIFTY 50", "SENSEX", "BANKNIFTY"];

function compactUpper(value: string): string {
  return value.replace(/[^A-Z0-9]/gi, "").toUpperCase();
}

/**
 * Bug fix: the old match used `tradingSymbol.includes(compact)` — only
 * correct when the *broker's* symbol is the longer string. For "NIFTY 50"
 * `compact` is "NIFTY50" (7 chars), but the real index symbol is almost
 * certainly just "NIFTY" (5 chars) — a longer string can never be found
 * inside a shorter one, so this silently failed every time while SENSEX/
 * BANKNIFTY happened to match exactly and worked by coincidence. Checking
 * both directions (does the query start with the symbol, or the symbol
 * start with the query) fixes it regardless of which side is longer.
 */
function matchesIndexName(item: Instrument, compact: string): boolean {
  if (!item.isIndex || !item.token) return false;
  const symCompact = compactUpper(item.tradingSymbol || item.symbol || "");
  if (!symCompact) return false;
  return compact.startsWith(symCompact) || symCompact.startsWith(compact);
}

/** User-managed index strip. Symbols are resolved from the broker master, not fixed tokens. */
export default function MarketIndexStrip() {
  const [names, setNames] = useState<string[]>(DEFAULT_NAMES);
  const [instruments, setInstruments] = useState<Instrument[]>([]);
  const [query, setQuery] = useState("");
  const { quotes, quotesByToken } = useMarketStream(instruments);

  useEffect(() => {
    try {
      const saved = JSON.parse(window.localStorage.getItem(STORAGE_KEY) ?? "null");
      if (Array.isArray(saved) && saved.every((item) => typeof item === "string")) setNames(saved);
    } catch { /* use defaults */ }
  }, []);

  useEffect(() => {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(names));
    let cancelled = false;

    async function resolveOne(name: string): Promise<Instrument | null> {
      const compact = compactUpper(name);
      // Try the name as given first, then fall back to just its first word
      // ("NIFTY" from "NIFTY 50") in case the broker's search doesn't like
      // multi-word queries — cheap extra chance, only fires if the first
      // attempt comes back empty.
      const queries = [name];
      const firstWord = name.trim().split(/\s+/)[0];
      if (firstWord && firstWord !== name) queries.push(firstWord);

      for (const q of queries) {
        try {
          const res = await fetch(`/api/broker/scrip-lookup?q=${encodeURIComponent(q)}`, { credentials: "include" });
          const json = await res.json();
          const hits = json?.data?.result?.hits?.hits ?? json?.data?.hits?.hits ?? [];
          const candidates: Instrument[] = hits.map((hit: Record<string, unknown>) => normalizeInstrument(hit));

          const found =
            candidates.find((item) => matchesIndexName(item, compact)) ??
            candidates.find((item) => item.isIndex && item.token);
          if (found) return found;
        } catch {
          /* try next query variant */
        }
      }
      return null;
    }

    Promise.all(names.map(resolveOne))
      .then((resolved) => {
        if (!cancelled) setInstruments(resolved.filter((item): item is Instrument => !!item));
      })
      .catch(() => {
        if (!cancelled) setInstruments([]);
      });

    return () => { cancelled = true; };
  }, [names]);

  const remove = (name: string) => setNames((current) => current.filter((item) => item !== name));
  const add = () => {
    const name = query.trim().toUpperCase();
    if (name && !names.includes(name)) setNames((current) => [...current, name]);
    setQuery("");
  };

  if (names.length === 0 && !query) return <div className="flex h-8 items-center border-b border-aveon-border px-3"><button onClick={() => setQuery(" ")} className="text-xs text-aveon-primary">+ Add index</button></div>;
  return <div className="flex h-9 shrink-0 items-center gap-1 overflow-x-auto border-b border-aveon-border bg-aveon-panel px-2">
    {instruments.map((instrument) => {
      const tokenKey = feedToken(instrument) ?? "";
      const quote = quotesByToken[tokenKey] ?? quotes[instrument.tradingSymbol] ?? quotes[instrument.symbol];
      const tone = quote ? pnlTone(quote.change) : "neutral";
      const savedName = names.find((name) => matchesIndexName(instrument, compactUpper(name))) ?? instrument.displayName ?? instrument.tradingSymbol;
      return <div key={instrument.tradingSymbol} className="flex shrink-0 items-center gap-2 border-r border-aveon-border px-3 text-xs"><span className="font-medium">{instrumentDisplayName(instrument)}</span><span className="font-semibold">{quote ? formatNumber(quote.ltp) : "—"}</span>{quote && <><span className={tone === "buy" ? "text-aveon-buy" : tone === "sell" ? "text-aveon-sell" : "text-aveon-muted"}>{quote.change >= 0 ? "+" : ""}{formatNumber(quote.change)}</span><span className={tone === "buy" ? "text-aveon-buy" : tone === "sell" ? "text-aveon-sell" : "text-aveon-muted"}>{quote.change_percent >= 0 ? "+" : ""}{formatNumber(quote.change_percent)}%</span></>}<button onClick={() => remove(savedName)} title={`Remove ${instrument.tradingSymbol}`} className="text-aveon-muted hover:text-aveon-sell"><X size={12} /></button></div>;
    })}
    <form onSubmit={(event) => { event.preventDefault(); add(); }} className="flex shrink-0 items-center gap-1 px-2"><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Add index" className="w-24 bg-transparent text-xs outline-none placeholder:text-aveon-muted" /><button aria-label="Add index" className="text-aveon-primary"><Plus size={14} /></button></form>
  </div>;
}
